import React, { useState } from 'react';
import { ethers } from 'ethers';
import { fetchIsRegistered, fetchUserName, fetchAdmin, registerUser, getSigner } from '../blockchain';

const S = {
  page: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#0a0e0f',
    padding: 24,
  },
  bg: {
    position: 'fixed', inset: 0,
    background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(0,212,170,0.06) 0%, transparent 70%)',
    pointerEvents: 'none',
  },
  card: {
    background: '#111618',
    border: '1px solid #1e2a2d',
    borderRadius: 16,
    padding: '48px 40px',
    width: '100%',
    maxWidth: 420,
    position: 'relative',
    boxShadow: '0 24px 64px rgba(0,0,0,0.5)',
    animation: 'fadeIn 0.5s ease',
  },
  logo: {
    textAlign: 'center',
    marginBottom: 32,
  },
  emoji: { fontSize: 40, display: 'block', marginBottom: 12 },
  title: {
    fontFamily: 'Syne, sans-serif',
    fontWeight: 800,
    fontSize: 26,
    color: '#e8f0f2',
  },
  sub: { color: '#8fa8b0', fontSize: 14, marginTop: 6 },
  label: {
    display: 'block',
    fontSize: 12,
    fontWeight: 600,
    color: '#8fa8b0',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
  },
  field: { marginBottom: 20 },
  hint: { fontSize: 12, color: '#4d6870', marginTop: 6 },
  btn: {
    width: '100%',
    background: 'linear-gradient(135deg, #00d4aa, #00a882)',
    color: '#0a0e0f',
    fontFamily: 'Syne, sans-serif',
    fontWeight: 700,
    fontSize: 15,
    padding: '14px',
    borderRadius: 10,
    border: 'none',
    cursor: 'pointer',
    marginTop: 8,
    transition: 'opacity 0.2s',
  },
  divider: {
    textAlign: 'center',
    color: '#4d6870',
    fontSize: 12,
    margin: '20px 0',
    position: 'relative',
  },
  info: {
    background: '#0a0e0f',
    border: '1px solid #1e2a2d',
    borderRadius: 8,
    padding: '12px 14px',
    fontSize: 12,
    color: '#8fa8b0',
    marginBottom: 20,
  },
  infoTitle: { color: '#00d4aa', fontWeight: 600, marginBottom: 4 },
};

export default function Login({ onLogin, showToast }) {
  const [wallet, setWallet]       = useState('');
  const [privKey, setPrivKey]     = useState('');
  const [dispName, setDispName]   = useState('');
  const [needsReg, setNeedsReg]   = useState(false);
  const [loading, setLoading]     = useState(false);
  const [step, setStep]           = useState(1); // 1=wallet+key, 2=register name

  const handleConnect = async () => {
    if (!wallet || !privKey) return showToast('Enter wallet address and private key', 'error');
    let addr;
    try { addr = ethers.getAddress(wallet); } catch { return showToast('Invalid wallet address', 'error'); }

    setLoading(true);
    try {
      const registered = await fetchIsRegistered(addr);
      const adminAddr  = await fetchAdmin();
      const isAdmin    = addr.toLowerCase() === adminAddr.toLowerCase();

      if (!registered) {
        setNeedsReg(true);
        setStep(2);
        setLoading(false);
        return;
      }

      const name = await fetchUserName(addr);
      showToast(`Welcome back, ${name || addr.slice(0,8)}!`);
      onLogin({ wallet: addr, name, privateKey: privKey, isAdmin });
    } catch (e) {
      showToast('Connection failed — is Ganache running?', 'error');
    }
    setLoading(false);
  };

  const handleRegister = async () => {
    if (!dispName.trim()) return showToast('Enter a display name', 'error');
    setLoading(true);
    try {
      const signer = getSigner(privKey);
      const addr   = ethers.getAddress(wallet);
      await registerUser(signer, dispName.trim());
      const adminAddr = await fetchAdmin();
      const isAdmin   = addr.toLowerCase() === adminAddr.toLowerCase();
      showToast(`Registered as "${dispName}" 🎉`);
      onLogin({ wallet: addr, name: dispName.trim(), privateKey: privKey, isAdmin });
    } catch (e) {
      showToast('Registration failed: ' + (e.reason || e.message), 'error');
    }
    setLoading(false);
  };

  return (
    <div style={S.page}>
      <div style={S.bg} />
      <div style={S.card}>
        <div style={S.logo}>
          <span style={S.emoji}>🌍</span>
          <div style={S.title}>Charity Tracker</div>
          <div style={S.sub}>Blockchain Donation Platform</div>
        </div>

        {step === 1 && (
          <>
            <div style={S.info}>
              <div style={S.infoTitle}>How to connect</div>
              Open Ganache → copy any account address and its private key (🔑 icon)
            </div>

            <div style={S.field}>
              <label style={S.label}>Wallet Address</label>
              <input
                value={wallet}
                onChange={e => setWallet(e.target.value)}
                placeholder="0x..."
              />
            </div>

            <div style={S.field}>
              <label style={S.label}>Private Key</label>
              <input
                type="password"
                value={privKey}
                onChange={e => setPrivKey(e.target.value)}
                placeholder="0x..."
              />
              <div style={S.hint}>⚠️ Local Ganache only — never use real keys</div>
            </div>

            <button
              style={{ ...S.btn, opacity: loading ? 0.6 : 1 }}
              onClick={handleConnect}
              disabled={loading}
            >
              {loading ? 'Connecting…' : 'Connect Wallet →'}
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <div style={{ ...S.info, borderColor: '#00d4aa55', background: 'rgba(0,212,170,0.05)' }}>
              <div style={S.infoTitle}>New User Detected!</div>
              Choose a display name to register on-chain.
            </div>

            <div style={S.field}>
              <label style={S.label}>Display Name</label>
              <input
                value={dispName}
                onChange={e => setDispName(e.target.value)}
                placeholder="e.g. Ahmed"
                autoFocus
              />
            </div>

            <button
              style={{ ...S.btn, opacity: loading ? 0.6 : 1 }}
              onClick={handleRegister}
              disabled={loading}
            >
              {loading ? 'Registering on blockchain…' : 'Register & Enter →'}
            </button>

            <div style={{ ...S.hint, textAlign: 'center', marginTop: 16 }}>
              <span style={{ cursor: 'pointer', color: '#8fa8b0' }} onClick={() => setStep(1)}>
                ← Back
              </span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
