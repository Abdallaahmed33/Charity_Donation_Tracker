import React, { useState } from 'react';
import { ethers } from 'ethers';
import { fetchBalances, fetchUserName, fetchIsRegistered } from '../blockchain';

const S = {
  title: { fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color: '#e8f0f2', marginBottom: 8 },
  sub: { color: '#8fa8b0', fontSize: 14, marginBottom: 28 },
  card: { background: '#111618', border: '1px solid #1e2a2d', borderRadius: 12, padding: 28, maxWidth: 500 },
  label: { display: 'block', fontSize: 12, fontWeight: 600, color: '#8fa8b0', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' },
  inputRow: { display: 'flex', gap: 10, marginBottom: 24 },
  btn: {
    background: 'linear-gradient(135deg, #00d4aa, #00a882)',
    color: '#0a0e0f', fontFamily: 'Syne, sans-serif', fontWeight: 700,
    fontSize: 14, padding: '10px 20px', borderRadius: 8, border: 'none',
    cursor: 'pointer', whiteSpace: 'nowrap',
  },
  myBtn: {
    background: 'transparent', border: '1px solid #1e2a2d',
    color: '#8fa8b0', fontSize: 13, padding: '10px 16px', borderRadius: 8,
    cursor: 'pointer', whiteSpace: 'nowrap',
  },
  result: { animation: 'fadeIn 0.3s ease' },
  nameRow: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 },
  avatar: {
    width: 44, height: 44, borderRadius: '50%',
    background: 'linear-gradient(135deg, #00d4aa, #00a882)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, color: '#0a0e0f',
  },
  nameInfo: {},
  nameVal: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2' },
  addrVal: { fontSize: 12, color: '#4d6870', marginTop: 2 },
  balRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 },
  balCard: (color) => ({
    background: '#0a0e0f', border: `1px solid ${color}33`,
    borderRadius: 10, padding: '16px',
  }),
  balLabel: { fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#4d6870', marginBottom: 8 },
  balVal: (color) => ({ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 26, color }),
  balUnit: { fontSize: 13, color: '#8fa8b0', marginLeft: 4 },
  unregistered: { fontSize: 13, color: '#f5c542', marginTop: 8 },
  error: { color: '#ff4d6a', fontSize: 13, marginTop: 8 },
};

export default function Balances({ session, showToast }) {
  const [addr,    setAddr]    = useState('');
  const [result,  setResult]  = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');

  const lookup = async (address) => {
    setError('');
    setResult(null);
    let checksum;
    try { checksum = ethers.getAddress(address); } catch { setError('Invalid address'); return; }

    setLoading(true);
    try {
      const [bal, name, registered] = await Promise.all([
        fetchBalances(checksum),
        fetchUserName(checksum),
        fetchIsRegistered(checksum),
      ]);
      setResult({ address: checksum, bal, name, registered });
    } catch (e) {
      setError('Lookup failed: ' + e.message);
    }
    setLoading(false);
  };

  const lookupMine = () => {
    setAddr(session.wallet);
    lookup(session.wallet);
  };

  return (
    <div className="animate-in">
      <div style={S.title}>Check Balances</div>
      <div style={S.sub}>Look up any wallet's ETH and DNC Donor Coin balance</div>

      <div style={S.card}>
        <label style={S.label}>Wallet Address</label>
        <div style={S.inputRow}>
          <input
            value={addr}
            onChange={e => setAddr(e.target.value)}
            placeholder="0x..."
            onKeyDown={e => e.key === 'Enter' && lookup(addr)}
          />
          <button style={S.btn} onClick={() => lookup(addr)} disabled={loading}>
            {loading ? '…' : 'Lookup'}
          </button>
          <button style={S.myBtn} onClick={lookupMine}>Mine</button>
        </div>

        {error && <div style={S.error}>{error}</div>}

        {result && (
          <div style={S.result}>
            <div style={S.nameRow}>
              <div style={S.avatar}>
                {(result.name || result.address.slice(2, 4)).slice(0, 1).toUpperCase()}
              </div>
              <div style={S.nameInfo}>
                <div style={S.nameVal}>{result.name || '(not registered)'}</div>
                <div style={S.addrVal}>{result.address.slice(0,10)}…{result.address.slice(-8)}</div>
              </div>
            </div>

            <div style={S.balRow}>
              <div style={S.balCard('#00d4aa')}>
                <div style={S.balLabel}>ETH Balance</div>
                <div style={S.balVal('#00d4aa')}>
                  {result.bal.eth}
                  <span style={S.balUnit}>ETH</span>
                </div>
              </div>
              <div style={S.balCard('#f5c542')}>
                <div style={S.balLabel}>Donor Coins</div>
                <div style={S.balVal('#f5c542')}>
                  {parseFloat(result.bal.dnc).toLocaleString()}
                  <span style={S.balUnit}>DNC</span>
                </div>
              </div>
            </div>

            {!result.registered && (
              <div style={S.unregistered}>⚠️ This address is not registered on-chain</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
