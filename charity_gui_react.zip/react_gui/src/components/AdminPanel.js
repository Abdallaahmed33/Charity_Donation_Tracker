import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import {
  getSigner, fetchAllCampaigns, fetchIsPaused,
  addCampaign, updateCampaign, mintCoins,
  pauseContract, resumeContract,
  transferOwnership, withdrawFunds,
} from '../blockchain';

const S = {
  title: { fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color: '#e8f0f2', marginBottom: 8 },
  sub: { color: '#8fa8b0', fontSize: 14, marginBottom: 28 },
  tabs: { display: 'flex', gap: 8, marginBottom: 28, flexWrap: 'wrap' },
  tab: (active) => ({
    padding: '8px 18px', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600,
    background: active ? 'rgba(0,212,170,0.1)' : 'transparent',
    border: `1px solid ${active ? '#00d4aa55' : '#1e2a2d'}`,
    color: active ? '#00d4aa' : '#8fa8b0', transition: 'all 0.15s',
  }),
  card: { background: '#111618', border: '1px solid #1e2a2d', borderRadius: 12, padding: 28, maxWidth: 520 },
  label: { display: 'block', fontSize: 12, fontWeight: 600, color: '#8fa8b0', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' },
  field: { marginBottom: 18 },
  btn: (color) => ({
    background: color === 'red'
      ? 'linear-gradient(135deg, #ff4d6a, #cc3352)'
      : color === 'yellow'
      ? 'linear-gradient(135deg, #f5c542, #d4a400)'
      : 'linear-gradient(135deg, #00d4aa, #00a882)',
    color: color === 'yellow' ? '#0a0e0f' : color === 'red' ? '#fff' : '#0a0e0f',
    fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14,
    padding: '12px 24px', borderRadius: 8, border: 'none', cursor: 'pointer',
    marginTop: 8, transition: 'opacity 0.2s',
  }),
  danger: { background: 'rgba(255,77,106,0.08)', border: '1px solid #ff4d6a33', borderRadius: 10, padding: '16px 20px', marginBottom: 16 },
  dangerTitle: { color: '#ff4d6a', fontFamily: 'Syne, sans-serif', fontWeight: 700, marginBottom: 6 },
  dangerText: { color: '#8fa8b0', fontSize: 13 },
  select: { background: '#0a0e0f', border: '1px solid #263035', borderRadius: 8, color: '#e8f0f2', padding: '10px 14px', width: '100%', marginBottom: 18 },
  success: { color: '#00d4aa', fontSize: 13, marginTop: 10, fontWeight: 600 },
  paused: { color: '#ff4d6a', fontSize: 13, marginTop: 10, fontWeight: 600 },
};

const TABS = [
  { id: 'campaigns', label: '📋 Campaigns' },
  { id: 'coins',     label: '🪙 Mint Coins' },
  { id: 'control',  label: '⚙️ Control' },
  { id: 'danger',   label: '🔴 Danger Zone' },
];

export default function AdminPanel({ session, showToast, setPaused: setGlobalPaused }) {
  const [tab,       setTab]       = useState('campaigns');
  const [campaigns, setCampaigns] = useState([]);
  const [paused,    setPaused]    = useState(false);
  const [loading,   setLoading]   = useState(false);
  const [msg,       setMsg]       = useState('');

  // Add campaign form
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newGoal, setNewGoal] = useState('');

  // Update campaign form
  const [upId,   setUpId]   = useState('');
  const [upName, setUpName] = useState('');
  const [upDesc, setUpDesc] = useState('');
  const [upGoal, setUpGoal] = useState('');

  // Mint coins form
  const [mintTo,  setMintTo]  = useState('');
  const [mintAmt, setMintAmt] = useState('');

  // Control forms
  const [newOwner,    setNewOwner]    = useState('');
  const [withdrawId,  setWithdrawId]  = useState('');
  const [withdrawTo,  setWithdrawTo]  = useState('');

  useEffect(() => {
    fetchAllCampaigns().then(setCampaigns);
    fetchIsPaused().then(p => { setPaused(p); setGlobalPaused(p); });
  }, []);

  const signer = () => getSigner(session.privateKey);
  const ok  = (m) => { setMsg(m); showToast(m); };
  const err = (e) => showToast((e.reason || e.message || 'Transaction failed'), 'error');

  const doAddCampaign = async () => {
    if (!newName || !newGoal) return showToast('Fill all fields', 'error');
    setLoading(true);
    try {
      await addCampaign(signer(), newName, newDesc, newGoal);
      ok('Campaign added!');
      setNewName(''); setNewDesc(''); setNewGoal('');
      setCampaigns(await fetchAllCampaigns());
    } catch (e) { err(e); }
    setLoading(false);
  };

  const doUpdateCampaign = async () => {
    if (upId === '' || !upName || !upGoal) return showToast('Fill all fields', 'error');
    setLoading(true);
    try {
      await updateCampaign(signer(), parseInt(upId), upName, upDesc, upGoal);
      ok('Campaign updated!');
      setCampaigns(await fetchAllCampaigns());
    } catch (e) { err(e); }
    setLoading(false);
  };

  const doMint = async () => {
    if (!mintTo || !mintAmt) return showToast('Fill all fields', 'error');
    try { ethers.getAddress(mintTo); } catch { return showToast('Invalid address', 'error'); }
    setLoading(true);
    try {
      await mintCoins(signer(), mintTo, mintAmt);
      ok('Minted ' + mintAmt + ' DNC to ' + mintTo.slice(0,10) + '…');
      setMintTo(''); setMintAmt('');
    } catch (e) { err(e); }
    setLoading(false);
  };

  const doTogglePause = async () => {
    setLoading(true);
    try {
      if (paused) { await resumeContract(signer()); setPaused(false); setGlobalPaused(false); ok('Contract RESUMED'); }
      else        { await pauseContract(signer());  setPaused(true);  setGlobalPaused(true);  ok('Contract PAUSED'); }
    } catch (e) { err(e); }
    setLoading(false);
  };

  const doTransfer = async () => {
    if (!newOwner) return showToast('Enter new admin address', 'error');
    try { ethers.getAddress(newOwner); } catch { return showToast('Invalid address', 'error'); }
    if (!window.confirm('Transfer ownership to ' + newOwner + '?\nYou will lose admin access!')) return;
    setLoading(true);
    try {
      await transferOwnership(signer(), newOwner);
      ok('Ownership transferred to ' + newOwner.slice(0,10) + '…');
    } catch (e) { err(e); }
    setLoading(false);
  };

  const doWithdraw = async () => {
    if (withdrawId === '' || !withdrawTo) return showToast('Fill all fields', 'error');
    setLoading(true);
    try {
      await withdrawFunds(signer(), parseInt(withdrawId), withdrawTo);
      ok('Funds withdrawn!');
      setCampaigns(await fetchAllCampaigns());
    } catch (e) { err(e); }
    setLoading(false);
  };

  return (
    <div className="animate-in">
      <div style={S.title}>👑 Admin Panel</div>
      <div style={S.sub}>Manage campaigns, coins, and contract settings</div>

      <div style={S.tabs}>
        {TABS.map(t => (
          <div key={t.id} style={S.tab(tab === t.id)} onClick={() => { setTab(t.id); setMsg(''); }}>
            {t.label}
          </div>
        ))}
      </div>

      {/* ── CAMPAIGNS TAB ── */}
      {tab === 'campaigns' && (
        <div style={{ display: 'grid', gap: 24, gridTemplateColumns: '1fr 1fr' }}>
          <div style={S.card}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2', marginBottom: 20 }}>
              Add New Campaign
            </div>
            <div style={S.field}><label style={S.label}>Campaign Name</label><input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. Clean Water Initiative" /></div>
            <div style={S.field}><label style={S.label}>Description</label><input value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Short description" /></div>
            <div style={S.field}><label style={S.label}>Goal (ETH)</label><input type="number" min="0" step="0.1" value={newGoal} onChange={e => setNewGoal(e.target.value)} placeholder="10.0" /></div>
            <button style={S.btn('green')} onClick={doAddCampaign} disabled={loading}>
              {loading ? 'Adding…' : '+ Add Campaign'}
            </button>
            {msg && <div style={S.success}>✅ {msg}</div>}
          </div>

          <div style={S.card}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2', marginBottom: 20 }}>
              Update Campaign
            </div>
            <div style={S.field}>
              <label style={S.label}>Select Campaign</label>
              <select style={S.select} value={upId} onChange={e => {
                const c = campaigns[e.target.value];
                setUpId(e.target.value);
                if (c) { setUpName(c.name); setUpDesc(c.desc); setUpGoal(c.target); }
              }}>
                <option value="">— choose —</option>
                {campaigns.map(c => <option key={c.id} value={c.id}>#{c.id} — {c.name}</option>)}
              </select>
            </div>
            <div style={S.field}><label style={S.label}>New Name</label><input value={upName} onChange={e => setUpName(e.target.value)} /></div>
            <div style={S.field}><label style={S.label}>New Description</label><input value={upDesc} onChange={e => setUpDesc(e.target.value)} /></div>
            <div style={S.field}><label style={S.label}>New Goal (ETH)</label><input type="number" min="0" step="0.1" value={upGoal} onChange={e => setUpGoal(e.target.value)} /></div>
            <button style={S.btn('green')} onClick={doUpdateCampaign} disabled={loading}>
              {loading ? 'Updating…' : 'Update Campaign'}
            </button>
          </div>
        </div>
      )}

      {/* ── MINT COINS TAB ── */}
      {tab === 'coins' && (
        <div style={S.card}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2', marginBottom: 20 }}>
            Mint Donor Coins
          </div>
          <div style={S.field}><label style={S.label}>Recipient Address</label><input value={mintTo} onChange={e => setMintTo(e.target.value)} placeholder="0x..." /></div>
          <div style={S.field}><label style={S.label}>Amount (DNC)</label><input type="number" min="0" value={mintAmt} onChange={e => setMintAmt(e.target.value)} placeholder="1000" /></div>
          <button style={S.btn('yellow')} onClick={doMint} disabled={loading}>
            {loading ? 'Minting…' : '🪙 Mint Coins'}
          </button>
          {msg && <div style={S.success}>✅ {msg}</div>}
        </div>
      )}

      {/* ── CONTROL TAB ── */}
      {tab === 'control' && (
        <div style={{ display: 'grid', gap: 24 }}>
          <div style={S.card}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2', marginBottom: 12 }}>
              Contract Status
            </div>
            <div style={{ color: paused ? '#ff4d6a' : '#00d4aa', fontSize: 14, marginBottom: 16, fontWeight: 600 }}>
              {paused ? '⏸ Contract is PAUSED — donations disabled' : '▶ Contract is ACTIVE'}
            </div>
            <button style={S.btn(paused ? 'green' : 'red')} onClick={doTogglePause} disabled={loading}>
              {loading ? 'Processing…' : paused ? '▶ Resume Contract' : '⏸ Pause Contract'}
            </button>
          </div>

          <div style={S.card}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2', marginBottom: 12 }}>
              Withdraw Campaign Funds
            </div>
            <div style={S.field}>
              <label style={S.label}>Select Campaign</label>
              <select style={S.select} value={withdrawId} onChange={e => setWithdrawId(e.target.value)}>
                <option value="">— choose —</option>
                {campaigns.map(c => <option key={c.id} value={c.id}>#{c.id} — {c.name} ({parseFloat(c.raised).toFixed(4)} ETH)</option>)}
              </select>
            </div>
            <div style={S.field}><label style={S.label}>Recipient Address</label><input value={withdrawTo} onChange={e => setWithdrawTo(e.target.value)} placeholder="0x..." /></div>
            <button style={S.btn('yellow')} onClick={doWithdraw} disabled={loading}>
              {loading ? 'Withdrawing…' : 'Withdraw Funds'}
            </button>
            {msg && <div style={S.success}>✅ {msg}</div>}
          </div>
        </div>
      )}

      {/* ── DANGER ZONE TAB ── */}
      {tab === 'danger' && (
        <div style={S.card}>
          <div style={S.danger}>
            <div style={S.dangerTitle}>⚠️ Transfer Ownership</div>
            <div style={S.dangerText}>This will permanently give admin rights to another address. You will lose all admin access immediately.</div>
          </div>
          <div style={S.field}><label style={S.label}>New Admin Address</label><input value={newOwner} onChange={e => setNewOwner(e.target.value)} placeholder="0x..." /></div>
          <button style={S.btn('red')} onClick={doTransfer} disabled={loading}>
            {loading ? 'Transferring…' : '🔴 Transfer Ownership'}
          </button>
          {msg && <div style={S.success}>✅ {msg}</div>}
        </div>
      )}
    </div>
  );
}
