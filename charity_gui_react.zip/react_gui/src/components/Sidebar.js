import React from 'react';

const S = {
  sidebar: {
    width: 240,
    background: '#111618',
    borderRight: '1px solid #1e2a2d',
    position: 'fixed',
    top: 0, left: 0, bottom: 0,
    display: 'flex',
    flexDirection: 'column',
    padding: '24px 0',
    zIndex: 100,
  },
  logo: {
    padding: '0 24px 24px',
    borderBottom: '1px solid #1e2a2d',
    marginBottom: 8,
  },
  logoTitle: {
    fontFamily: 'Syne, sans-serif',
    fontWeight: 800,
    fontSize: 18,
    color: '#00d4aa',
    lineHeight: 1.2,
  },
  logoSub: {
    fontSize: 11,
    color: '#4d6870',
    marginTop: 2,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
  },
  nav: { flex: 1, padding: '8px 12px', overflowY: 'auto' },
  navItem: (active) => ({
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '10px 12px',
    borderRadius: 8,
    cursor: 'pointer',
    marginBottom: 2,
    transition: 'all 0.15s',
    background: active ? 'rgba(0,212,170,0.1)' : 'transparent',
    color: active ? '#00d4aa' : '#8fa8b0',
    fontWeight: active ? 600 : 400,
    fontSize: 14,
    border: active ? '1px solid rgba(0,212,170,0.2)' : '1px solid transparent',
  }),
  icon: { fontSize: 16, width: 20, textAlign: 'center' },
  section: {
    padding: '8px 24px 4px',
    fontSize: 10,
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    color: '#4d6870',
    marginTop: 8,
  },
  bottom: {
    padding: '16px 12px',
    borderTop: '1px solid #1e2a2d',
    margin: '0 0',
  },
  wallet: {
    padding: '10px 12px',
    background: '#0a0e0f',
    borderRadius: 8,
    marginBottom: 8,
  },
  walletLabel: { fontSize: 10, color: '#4d6870', textTransform: 'uppercase', letterSpacing: '0.08em' },
  walletAddr: { fontSize: 12, color: '#8fa8b0', marginTop: 2, wordBreak: 'break-all' },
  walletName: { fontSize: 13, color: '#00d4aa', fontWeight: 600, marginTop: 2 },
  pauseBadge: {
    display: 'inline-block',
    background: 'rgba(255,77,106,0.15)',
    color: '#ff4d6a',
    fontSize: 10,
    padding: '2px 8px',
    borderRadius: 4,
    marginTop: 6,
    fontWeight: 600,
  },
  logoutBtn: {
    width: '100%',
    background: 'transparent',
    border: '1px solid #1e2a2d',
    color: '#8fa8b0',
    padding: '8px',
    borderRadius: 8,
    fontSize: 13,
    cursor: 'pointer',
    transition: 'all 0.15s',
  },
};

const NAV = [
  { id: 'dashboard', icon: '⬡', label: 'Dashboard' },
  { id: 'campaigns', icon: '📋', label: 'Campaigns' },
  { id: 'donate',    icon: '💚', label: 'Donate' },
  { id: 'balances',  icon: '💰', label: 'Balances' },
  { id: 'activity',  icon: '📜', label: 'Activity' },
];

export default function Sidebar({ session, page, setPage, paused, onLogout }) {
  return (
    <div style={S.sidebar}>
      <div style={S.logo}>
        <div style={S.logoTitle}>🌍 Charity<br/>Tracker</div>
        <div style={S.logoSub}>Blockchain Platform</div>
      </div>

      <nav style={S.nav}>
        <div style={S.section}>Main</div>
        {NAV.map(n => (
          <div key={n.id} style={S.navItem(page === n.id)} onClick={() => setPage(n.id)}>
            <span style={S.icon}>{n.icon}</span>
            {n.label}
          </div>
        ))}

        {session.isAdmin && (
          <>
            <div style={S.section}>Admin</div>
            <div style={S.navItem(page === 'admin')} onClick={() => setPage('admin')}>
              <span style={S.icon}>👑</span>
              Admin Panel
            </div>
          </>
        )}
      </nav>

      <div style={S.bottom}>
        <div style={S.wallet}>
          <div style={S.walletLabel}>Connected Wallet</div>
          <div style={S.walletName}>{session.name || 'Anonymous'}</div>
          <div style={S.walletAddr}>{session.wallet.slice(0,8)}…{session.wallet.slice(-6)}</div>
          {session.isAdmin && <div style={S.pauseBadge}>👑 ADMIN</div>}
          {paused && <div style={S.pauseBadge}>⚠️ PAUSED</div>}
        </div>
        <button
          style={S.logoutBtn}
          onMouseEnter={e => { e.target.style.background='#1e2a2d'; e.target.style.color='#e8f0f2'; }}
          onMouseLeave={e => { e.target.style.background='transparent'; e.target.style.color='#8fa8b0'; }}
          onClick={onLogout}
        >
          ← Logout
        </button>
      </div>
    </div>
  );
}
