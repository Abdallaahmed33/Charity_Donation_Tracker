import React, { useEffect, useState } from 'react';
import { fetchAllCampaigns, fetchBalances } from '../blockchain';

const card = {
  background: '#111618',
  border: '1px solid #1e2a2d',
  borderRadius: 12,
  padding: '24px',
};

const S = {
  header: { marginBottom: 32 },
  title: { fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color: '#e8f0f2' },
  sub: { color: '#8fa8b0', marginTop: 6, fontSize: 14 },
  statsRow: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 32 },
  statCard: {
    ...card,
    background: 'linear-gradient(135deg, #111618, #141c1f)',
  },
  statLabel: { fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#4d6870', marginBottom: 8 },
  statValue: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 28, color: '#e8f0f2' },
  statUnit: { fontSize: 13, color: '#8fa8b0', marginLeft: 4 },
  accentStat: { color: '#00d4aa' },
  sectionTitle: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 18, marginBottom: 16, color: '#e8f0f2' },
  campaignList: { display: 'grid', gap: 12 },
  campaign: {
    ...card,
    padding: '20px',
    cursor: 'default',
    transition: 'border-color 0.2s',
  },
  camRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  camName: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, color: '#e8f0f2' },
  camDesc: { fontSize: 13, color: '#8fa8b0', marginTop: 3, maxWidth: '70%' },
  camEth: { textAlign: 'right' },
  camRaised: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#00d4aa' },
  camGoal: { fontSize: 12, color: '#4d6870', marginTop: 2 },
  barTrack: { height: 6, background: '#1e2a2d', borderRadius: 3, overflow: 'hidden' },
  barFill: (pct) => ({
    height: '100%',
    width: `${Math.min(pct, 100)}%`,
    background: pct >= 100 ? '#f5c542' : 'linear-gradient(90deg, #00d4aa, #00a882)',
    borderRadius: 3,
    transition: 'width 0.8s ease',
  }),
  pct: { fontSize: 12, color: '#8fa8b0', marginTop: 6, textAlign: 'right' },
  quickBtn: {
    display: 'inline-block',
    background: 'rgba(0,212,170,0.1)',
    border: '1px solid rgba(0,212,170,0.2)',
    color: '#00d4aa',
    padding: '8px 16px',
    borderRadius: 8,
    cursor: 'pointer',
    fontSize: 13,
    fontWeight: 600,
    marginRight: 10,
    marginTop: 24,
  },
  loading: { color: '#4d6870', fontStyle: 'italic', padding: '40px 0', textAlign: 'center' },
};

export default function Dashboard({ session, showToast, setPage }) {
  const [campaigns, setCampaigns] = useState([]);
  const [balances,  setBalances]  = useState(null);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [cmp, bal] = await Promise.all([
          fetchAllCampaigns(),
          fetchBalances(session.wallet),
        ]);
        setCampaigns(cmp);
        setBalances(bal);
      } catch (e) {
        showToast('Failed to load data', 'error');
      }
      setLoading(false);
    };
    load();
  }, []);

  const totalRaised = campaigns.reduce((s, c) => s + parseFloat(c.raised), 0);
  const totalGoal   = campaigns.reduce((s, c) => s + parseFloat(c.target), 0);

  return (
    <div className="animate-in">
      <div style={S.header}>
        <div style={S.title}>Welcome, {session.name} 👋</div>
        <div style={S.sub}>Here's what's happening on the blockchain today</div>
      </div>

      <div style={S.statsRow}>
        <div style={S.statCard}>
          <div style={S.statLabel}>Total Campaigns</div>
          <div style={S.statValue}><span style={S.accentStat}>{campaigns.length}</span></div>
        </div>
        <div style={S.statCard}>
          <div style={S.statLabel}>Total Raised</div>
          <div style={S.statValue}>
            <span style={S.accentStat}>{totalRaised.toFixed(3)}</span>
            <span style={S.statUnit}>ETH</span>
          </div>
        </div>
        <div style={S.statCard}>
          <div style={S.statLabel}>Your ETH Balance</div>
          <div style={S.statValue}>
            {balances ? <span style={S.accentStat}>{balances.eth}</span> : '…'}
            <span style={S.statUnit}>ETH</span>
          </div>
        </div>
        <div style={S.statCard}>
          <div style={S.statLabel}>Your DNC Coins</div>
          <div style={S.statValue}>
            {balances ? <span style={{ color: '#f5c542' }}>{parseFloat(balances.dnc).toLocaleString()}</span> : '…'}
            <span style={S.statUnit}>DNC</span>
          </div>
        </div>
      </div>

      <div style={S.sectionTitle}>Active Campaigns</div>

      {loading ? (
        <div style={S.loading}>Loading from blockchain…</div>
      ) : (
        <div style={S.campaignList}>
          {campaigns.map(c => {
            const pct = parseFloat(c.target) > 0 ? (parseFloat(c.raised) / parseFloat(c.target)) * 100 : 0;
            return (
              <div key={c.id} style={S.campaign}
                onMouseEnter={e => e.currentTarget.style.borderColor = '#263035'}
                onMouseLeave={e => e.currentTarget.style.borderColor = '#1e2a2d'}
              >
                <div style={S.camRow}>
                  <div>
                    <div style={S.camName}>#{c.id} — {c.name}</div>
                    <div style={S.camDesc}>{c.desc}</div>
                  </div>
                  <div style={S.camEth}>
                    <div style={S.camRaised}>{parseFloat(c.raised).toFixed(4)} ETH</div>
                    <div style={S.camGoal}>Goal: {parseFloat(c.target).toFixed(2)} ETH</div>
                  </div>
                </div>
                <div style={S.barTrack}><div style={S.barFill(pct)} /></div>
                <div style={S.pct}>{pct.toFixed(1)}% funded</div>
              </div>
            );
          })}
        </div>
      )}

      <div>
        <span style={S.quickBtn} onClick={() => setPage('donate')}>💚 Donate Now</span>
        <span style={S.quickBtn} onClick={() => setPage('activity')}>📜 My Activity</span>
      </div>
    </div>
  );
}
