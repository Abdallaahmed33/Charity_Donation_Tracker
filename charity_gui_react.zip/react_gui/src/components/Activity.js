import React, { useState } from 'react';
import { ethers } from 'ethers';
import { fetchActivityHistory } from '../blockchain';

const S = {
  title: { fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color: '#e8f0f2', marginBottom: 8 },
  sub: { color: '#8fa8b0', fontSize: 14, marginBottom: 28 },
  card: { background: '#111618', border: '1px solid #1e2a2d', borderRadius: 12, padding: 24 },
  label: { display: 'block', fontSize: 12, fontWeight: 600, color: '#8fa8b0', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' },
  inputRow: { display: 'flex', gap: 10, marginBottom: 8 },
  btn: {
    background: 'linear-gradient(135deg, #00d4aa, #00a882)',
    color: '#0a0e0f', fontFamily: 'Syne, sans-serif', fontWeight: 700,
    fontSize: 14, padding: '10px 20px', borderRadius: 8, border: 'none',
    cursor: 'pointer', whiteSpace: 'nowrap',
  },
  myBtn: {
    background: 'transparent', border: '1px solid #1e2a2d',
    color: '#8fa8b0', fontSize: 13, padding: '10px 16px',
    borderRadius: 8, cursor: 'pointer', whiteSpace: 'nowrap',
  },
  hint: { fontSize: 12, color: '#4d6870', marginBottom: 20 },
  table: { width: '100%', borderCollapse: 'collapse', marginTop: 16 },
  th: { textAlign: 'left', fontSize: 11, color: '#4d6870', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '8px 12px', borderBottom: '1px solid #1e2a2d' },
  td: { padding: '12px', borderBottom: '1px solid #1e2a2d', fontSize: 13, color: '#8fa8b0', verticalAlign: 'middle' },
  dirBadge: (dir) => ({
    display: 'inline-block',
    background: dir === 'SENT' ? 'rgba(0,212,170,0.1)' : 'rgba(245,197,66,0.1)',
    color: dir === 'SENT' ? '#00d4aa' : '#f5c542',
    border: `1px solid ${dir === 'SENT' ? '#00d4aa33' : '#f5c54233'}`,
    padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 600,
  }),
  hash: { fontSize: 11, color: '#4d6870', fontFamily: 'monospace' },
  empty: { textAlign: 'center', color: '#4d6870', padding: '40px 0', fontStyle: 'italic' },
  loading: { textAlign: 'center', color: '#4d6870', padding: '40px 0' },
  scanning: {
    background: 'rgba(0,212,170,0.06)', border: '1px solid #00d4aa22',
    borderRadius: 8, padding: '14px 16px', marginTop: 16, color: '#00d4aa', fontSize: 13,
    display: 'flex', alignItems: 'center', gap: 10,
  },
  spinner: {
    width: 16, height: 16, border: '2px solid #00d4aa33',
    borderTop: '2px solid #00d4aa', borderRadius: '50%',
    animation: 'spin 0.8s linear infinite', flexShrink: 0,
  },
};

export default function Activity({ session, showToast }) {
  const [addr,    setAddr]    = useState('');
  const [history, setHistory] = useState(null);
  const [loading, setLoading] = useState(false);

  const lookup = async (address) => {
    let checksum;
    try { checksum = ethers.getAddress(address); } catch { showToast('Invalid address', 'error'); return; }
    setLoading(true);
    setHistory(null);
    try {
      const data = await fetchActivityHistory(checksum);
      setHistory(data);
      if (data.length === 0) showToast('No activity found for this address', 'info');
    } catch (e) {
      showToast('Failed: ' + e.message, 'error');
    }
    setLoading(false);
  };

  return (
    <div className="animate-in">
      <div style={S.title}>Activity History</div>
      <div style={S.sub}>Scan the blockchain for any address's transaction history</div>

      <div style={S.card}>
        <label style={S.label}>Wallet Address</label>
        <div style={S.inputRow}>
          <input
            value={addr}
            onChange={e => setAddr(e.target.value)}
            placeholder="0x..."
            onKeyDown={e => e.key === 'Enter' && lookup(addr)}
          />
          <button style={S.btn} onClick={() => lookup(addr)} disabled={loading}>
            {loading ? '…' : 'Search'}
          </button>
          <button style={S.myBtn} onClick={() => { setAddr(session.wallet); lookup(session.wallet); }}>
            Mine
          </button>
        </div>
        <div style={S.hint}>⚡ Scans all blocks — may take a few seconds</div>

        {loading && (
          <div style={S.scanning}>
            <div style={S.spinner} />
            Scanning blockchain blocks…
          </div>
        )}

        {history !== null && !loading && (
          history.length === 0 ? (
            <div style={S.empty}>No transactions found for this address.</div>
          ) : (
            <>
              <div style={{ color: '#00d4aa', fontSize: 13, marginBottom: 8 }}>
                Found {history.length} transaction{history.length !== 1 ? 's' : ''}
              </div>
              <table style={S.table}>
                <thead>
                  <tr>
                    <th style={S.th}>Block</th>
                    <th style={S.th}>Direction</th>
                    <th style={S.th}>Value (ETH)</th>
                    <th style={S.th}>Tx Hash</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((tx, i) => (
                    <tr key={i}>
                      <td style={{ ...S.td, color: '#e8f0f2', fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                        #{tx.block}
                      </td>
                      <td style={S.td}>
                        <span style={S.dirBadge(tx.direction)}>{tx.direction}</span>
                      </td>
                      <td style={{ ...S.td, color: tx.value > 0 ? '#00d4aa' : '#4d6870' }}>
                        {tx.value > 0 ? tx.value : '—'}
                      </td>
                      <td style={S.td}>
                        <span style={S.hash}>{tx.hash.slice(0, 18)}…</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )
        )}
      </div>
    </div>
  );
}
