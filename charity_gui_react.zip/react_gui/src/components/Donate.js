import React, { useEffect, useState } from 'react';
import { fetchAllCampaigns, donateToCampaign, getSigner } from '../blockchain';

const S = {
  title: { fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color: '#e8f0f2', marginBottom: 8 },
  sub: { color: '#8fa8b0', fontSize: 14, marginBottom: 28 },
  layout: { display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, alignItems: 'start' },
  section: { background: '#111618', border: '1px solid #1e2a2d', borderRadius: 12, padding: 24 },
  sectionTitle: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: '#e8f0f2', marginBottom: 16 },
  campItem: (sel) => ({
    padding: '14px 16px', borderRadius: 8,
    border: `1px solid ${sel ? '#00d4aa55' : '#1e2a2d'}`,
    background: sel ? 'rgba(0,212,170,0.06)' : '#0a0e0f',
    cursor: 'pointer', marginBottom: 8, transition: 'all 0.15s',
  }),
  campName: (sel) => ({ fontWeight: 600, fontSize: 14, color: sel ? '#00d4aa' : '#e8f0f2' }),
  campMeta: { fontSize: 12, color: '#8fa8b0', marginTop: 4 },
  track: { height: 4, background: '#1e2a2d', borderRadius: 2, overflow: 'hidden', marginTop: 8 },
  fill: (pct) => ({
    height: '100%', width: `${Math.min(pct,100)}%`,
    background: 'linear-gradient(90deg, #00d4aa, #00a882)', borderRadius: 2,
  }),
  label: { display: 'block', fontSize: 12, fontWeight: 600, color: '#8fa8b0', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' },
  field: { marginBottom: 20 },
  amountRow: { display: 'flex', gap: 8, marginBottom: 8 },
  quickAmt: (sel) => ({
    flex: 1, padding: '8px', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600, textAlign: 'center',
    background: sel ? 'rgba(0,212,170,0.1)' : '#0a0e0f',
    border: `1px solid ${sel ? '#00d4aa55' : '#1e2a2d'}`,
    color: sel ? '#00d4aa' : '#8fa8b0', transition: 'all 0.15s',
  }),
  rewardBox: {
    background: 'linear-gradient(135deg, rgba(245,197,66,0.08), rgba(245,197,66,0.04))',
    border: '1px solid rgba(245,197,66,0.2)', borderRadius: 10, padding: '14px 16px', marginBottom: 20,
  },
  rewardLabel: { fontSize: 11, color: '#f5c542', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em' },
  rewardVal: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 20, color: '#f5c542', marginTop: 4 },
  btn: (disabled) => ({
    width: '100%', padding: '14px',
    background: disabled ? '#1e2a2d' : 'linear-gradient(135deg, #00d4aa, #00a882)',
    color: disabled ? '#4d6870' : '#0a0e0f',
    fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15,
    borderRadius: 10, border: 'none', cursor: disabled ? 'not-allowed' : 'pointer', transition: 'all 0.2s',
  }),
  successBox: {
    background: 'rgba(0,212,170,0.08)', border: '1px solid #00d4aa44',
    borderRadius: 10, padding: '20px', textAlign: 'center', animation: 'fadeIn 0.4s ease',
  },
  successTitle: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 18, color: '#00d4aa', marginBottom: 8 },
  successSub: { color: '#8fa8b0', fontSize: 14 },
};

const QUICK_AMTS = ['0.1', '0.5', '1.0', '2.0'];

export default function Donate({ session, showToast }) {
  const [campaigns, setCampaigns] = useState([]);
  const [selected,  setSelected]  = useState(null);
  const [amount,    setAmount]    = useState('');
  const [loading,   setLoading]   = useState(false);
  const [success,   setSuccess]   = useState(null);

  useEffect(() => {
    fetchAllCampaigns().then(setCampaigns).catch(() => showToast('Failed to load campaigns', 'error'));
  }, []);

  const canDonate = selected !== null && parseFloat(amount) > 0;

  const handleDonate = async () => {
    if (!canDonate) return;
    setLoading(true);
    try {
      const signer = getSigner(session.privateKey);
      await donateToCampaign(signer, selected, amount);
      setSuccess({ campaignName: campaigns[selected]?.name, amount });
      showToast('Donated ' + amount + ' ETH successfully! 🎉');
      setCampaigns(await fetchAllCampaigns());
    } catch (e) {
      showToast('Donation failed: ' + (e.reason || e.message), 'error');
    }
    setLoading(false);
  };

  if (success) return (
    <div className="animate-in">
      <div style={S.title}>Donate</div>
      <div style={{ maxWidth: 420, marginTop: 20 }}>
        <div style={S.successBox}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🎉</div>
          <div style={S.successTitle}>Donation Confirmed!</div>
          <div style={S.successSub}>
            You donated <strong style={{ color: '#00d4aa' }}>{success.amount} ETH</strong> to{' '}
            <strong style={{ color: '#e8f0f2' }}>{success.campaignName}</strong>
            <br />and earned <strong style={{ color: '#f5c542' }}>{(parseFloat(success.amount) * 1e20).toLocaleString()} DNC</strong> reward tokens!
          </div>
          <button style={{ ...S.btn(false), marginTop: 20 }}
            onClick={() => { setSuccess(null); setAmount(''); setSelected(null); }}>
            Donate Again
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="animate-in">
      <div style={S.title}>Donate</div>
      <div style={S.sub}>Choose a campaign and amount — earn DNC tokens as reward</div>

      <div style={S.layout}>
        <div style={S.section}>
          <div style={S.sectionTitle}>Select Campaign</div>
          {campaigns.map(c => {
            const pct = parseFloat(c.target) > 0 ? (parseFloat(c.raised) / parseFloat(c.target)) * 100 : 0;
            return (
              <div key={c.id} style={S.campItem(selected === c.id)} onClick={() => setSelected(c.id)}>
                <div style={S.campName(selected === c.id)}>#{c.id} — {c.name}</div>
                <div style={S.campMeta}>{parseFloat(c.raised).toFixed(4)} / {parseFloat(c.target).toFixed(2)} ETH raised</div>
                <div style={S.track}><div style={S.fill(pct)} /></div>
              </div>
            );
          })}
        </div>

        <div>
          <div style={S.section}>
            <div style={S.sectionTitle}>Amount (ETH)</div>
            <div style={S.amountRow}>
              {QUICK_AMTS.map(a => (
                <div key={a} style={S.quickAmt(amount === a)} onClick={() => setAmount(a)}>{a}</div>
              ))}
            </div>
            <div style={S.field}>
              <label style={S.label}>Custom Amount</label>
              <input type="number" min="0" step="0.01" value={amount}
                onChange={e => setAmount(e.target.value)} placeholder="0.00" />
            </div>
            {amount && parseFloat(amount) > 0 && (
              <div style={S.rewardBox}>
                <div style={S.rewardLabel}>🪙 DNC Reward You Will Earn</div>
                <div style={S.rewardVal}>{(parseFloat(amount) * 1e20).toLocaleString()} DNC</div>
              </div>
            )}
            <button style={S.btn(!canDonate || loading)} onClick={handleDonate} disabled={!canDonate || loading}>
              {loading ? 'Processing Transaction…' : canDonate ? 'Confirm Donation →' : 'Select Campaign & Amount'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
