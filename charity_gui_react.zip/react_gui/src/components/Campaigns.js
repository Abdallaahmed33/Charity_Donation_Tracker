import React, { useEffect, useState } from 'react';
import { fetchAllCampaigns } from '../blockchain';

const card = { background: '#111618', border: '1px solid #1e2a2d', borderRadius: 12, padding: 24 };

const S = {
  title: { fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color: '#e8f0f2', marginBottom: 8 },
  sub: { color: '#8fa8b0', fontSize: 14, marginBottom: 28 },
  grid: { display: 'grid', gap: 16, gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' },
  campaign: { ...card, transition: 'border-color 0.2s, transform 0.2s' },
  badge: {
    display: 'inline-block',
    background: 'rgba(0,212,170,0.1)',
    color: '#00d4aa',
    fontSize: 11,
    padding: '3px 8px',
    borderRadius: 4,
    fontWeight: 600,
    marginBottom: 10,
  },
  name: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 17, color: '#e8f0f2', marginBottom: 6 },
  desc: { fontSize: 13, color: '#8fa8b0', marginBottom: 16, lineHeight: 1.6 },
  numbers: { display: 'flex', justifyContent: 'space-between', marginBottom: 12, alignItems: 'flex-end' },
  raised: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 22, color: '#00d4aa' },
  raisedLabel: { fontSize: 11, color: '#4d6870', marginTop: 2 },
  goal: { textAlign: 'right' },
  goalVal: { fontFamily: 'Syne, sans-serif', fontWeight: 600, fontSize: 15, color: '#8fa8b0' },
  goalLabel: { fontSize: 11, color: '#4d6870' },
  track: { height: 8, background: '#1e2a2d', borderRadius: 4, overflow: 'hidden', marginBottom: 8 },
  fill: (pct) => ({
    height: '100%',
    width: `${Math.min(pct, 100)}%`,
    background: pct >= 100 ? 'linear-gradient(90deg, #f5c542, #f0a500)' : 'linear-gradient(90deg, #00d4aa, #00a882)',
    borderRadius: 4,
    transition: 'width 1s ease',
  }),
  pctRow: { display: 'flex', justifyContent: 'space-between', fontSize: 12 },
  pctVal: (pct) => ({ color: pct >= 100 ? '#f5c542' : '#00d4aa', fontWeight: 600 }),
  pctLabel: { color: '#4d6870' },
  reload: {
    background: 'transparent', border: '1px solid #1e2a2d',
    color: '#8fa8b0', padding: '8px 16px', borderRadius: 8,
    cursor: 'pointer', fontSize: 13, marginBottom: 24,
  },
  empty: { color: '#4d6870', textAlign: 'center', padding: '60px 0', fontStyle: 'italic' },
  loading: { color: '#4d6870', textAlign: 'center', padding: '60px 0' },
};

export default function Campaigns({ showToast }) {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading]     = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      setCampaigns(await fetchAllCampaigns());
    } catch {
      showToast('Failed to load campaigns', 'error');
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="animate-in">
      <div style={S.title}>All Campaigns</div>
      <div style={S.sub}>Browse all charity campaigns stored on the blockchain</div>

      <button style={S.reload} onClick={load}>↻ Refresh</button>

      {loading ? (
        <div style={S.loading}>Loading campaigns from blockchain…</div>
      ) : campaigns.length === 0 ? (
        <div style={S.empty}>No campaigns found. Ask admin to add some.</div>
      ) : (
        <div style={S.grid}>
          {campaigns.map(c => {
            const pct = parseFloat(c.target) > 0
              ? (parseFloat(c.raised) / parseFloat(c.target)) * 100
              : 0;
            return (
              <div key={c.id} style={S.campaign}
                onMouseEnter={e => { e.currentTarget.style.borderColor='#263035'; e.currentTarget.style.transform='translateY(-2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor='#1e2a2d'; e.currentTarget.style.transform='translateY(0)'; }}
              >
                <div style={S.badge}>Campaign #{c.id}</div>
                <div style={S.name}>{c.name}</div>
                <div style={S.desc}>{c.desc || 'No description provided.'}</div>
                <div style={S.numbers}>
                  <div>
                    <div style={S.raised}>{parseFloat(c.raised).toFixed(4)}<span style={{ fontSize: 14, marginLeft: 4, color: '#8fa8b0' }}>ETH</span></div>
                    <div style={S.raisedLabel}>Raised so far</div>
                  </div>
                  <div style={S.goal}>
                    <div style={S.goalVal}>{parseFloat(c.target).toFixed(2)} ETH</div>
                    <div style={S.goalLabel}>Fundraising goal</div>
                  </div>
                </div>
                <div style={S.track}><div style={S.fill(pct)} /></div>
                <div style={S.pctRow}>
                  <span style={S.pctVal(pct)}>{pct.toFixed(1)}% funded {pct >= 100 ? '🎉' : ''}</span>
                  <span style={S.pctLabel}>{(parseFloat(c.target) - parseFloat(c.raised)).toFixed(4)} ETH remaining</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
