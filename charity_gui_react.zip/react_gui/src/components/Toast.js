import React from 'react';

export default function Toast({ toast }) {
  const colors = {
    success: { bg: 'rgba(0,212,170,0.12)', border: '#00d4aa55', color: '#00d4aa' },
    error:   { bg: 'rgba(255,77,106,0.12)', border: '#ff4d6a55', color: '#ff4d6a' },
    info:    { bg: 'rgba(245,197,66,0.12)',  border: '#f5c54255', color: '#f5c542' },
  };
  const c = colors[toast.type] || colors.success;

  return (
    <div style={{
      position: 'fixed',
      bottom: 32, right: 32,
      background: c.bg,
      border: `1px solid ${c.border}`,
      color: c.color,
      padding: '14px 20px',
      borderRadius: 10,
      fontWeight: 600,
      fontSize: 14,
      zIndex: 9999,
      maxWidth: 340,
      boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
      animation: 'fadeIn 0.3s ease',
    }}>
      {toast.type === 'success' && '✅ '}
      {toast.type === 'error'   && '❌ '}
      {toast.type === 'info'    && '⚡ '}
      {toast.msg}
    </div>
  );
}
