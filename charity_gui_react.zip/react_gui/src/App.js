import React, { useState, useEffect } from 'react';
import Login      from './components/Login';
import Dashboard  from './components/Dashboard';
import Campaigns  from './components/Campaigns';
import Donate     from './components/Donate';
import Balances   from './components/Balances';
import Activity   from './components/Activity';
import AdminPanel from './components/AdminPanel';
import Sidebar    from './components/Sidebar';
import Toast      from './components/Toast';
import { fetchIsPaused } from './blockchain';

export default function App() {
  const [session, setSession] = useState(null);
  const [page,    setPage]    = useState('dashboard');
  const [toast,   setToast]   = useState(null);
  const [paused,  setPaused]  = useState(false);

  useEffect(() => {
    if (!session) return;
    const check = async () => { try { setPaused(await fetchIsPaused()); } catch {} };
    check();
    const id = setInterval(check, 10000);
    return () => clearInterval(id);
  }, [session]);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  if (!session) return (
    <>
      <Login onLogin={setSession} showToast={showToast} />
      {toast && <Toast toast={toast} />}
    </>
  );

  const pages = {
    dashboard: <Dashboard  session={session} showToast={showToast} setPage={setPage} />,
    campaigns: <Campaigns  session={session} showToast={showToast} setPage={setPage} />,
    donate:    <Donate     session={session} showToast={showToast} />,
    balances:  <Balances   session={session} showToast={showToast} />,
    activity:  <Activity   session={session} showToast={showToast} />,
    admin:     <AdminPanel session={session} showToast={showToast} setPaused={setPaused} />,
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar session={session} page={page} setPage={setPage} paused={paused}
        onLogout={() => { setSession(null); setPage('dashboard'); }} />

      <main style={{ flex: 1, marginLeft: 240, padding: 32, maxWidth: 'calc(100vw - 240px)' }}>
        {paused && (
          <div style={{
            background: 'rgba(255,77,106,0.1)', border: '1px solid #ff4d6a55',
            borderRadius: 10, padding: '12px 20px', marginBottom: 24,
            color: '#ff4d6a', fontFamily: 'Syne, sans-serif', fontWeight: 600,
          }}>
            ⚠️ Contract is currently PAUSED — donations are disabled
          </div>
        )}
        {pages[page] || pages.dashboard}
      </main>

      {toast && <Toast toast={toast} />}
    </div>
  );
}
