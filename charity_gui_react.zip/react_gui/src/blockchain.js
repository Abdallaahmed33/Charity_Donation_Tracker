import { ethers } from 'ethers';

const loadContracts = async () => {
  const [addrRes, abiRes] = await Promise.all([
    fetch('/deployed_addresses.json'),
    fetch('/contract_abis.json'),
  ]);
  if (!addrRes.ok || !abiRes.ok) {
    throw new Error('deployed_addresses.json or contract_abis.json not found in public folder');
  }
  const addresses = await addrRes.json();
  const abis = await abiRes.json();
  if (!addresses.charity_contract || !addresses.coin_contract) {
    throw new Error('Invalid deployed_addresses.json - run auto_setup.py first');
  }
  return { addresses, abis };
};

export const getProvider = () =>
  new ethers.JsonRpcProvider('http://127.0.0.1:7545');

export const getSigner = (privateKey) => {
  const provider = getProvider();
  return new ethers.Wallet(privateKey, provider);
};

let _contracts = null;

export const getContracts = async (signerOrProvider) => {
  if (!_contracts) {
    _contracts = await loadContracts();
  }
  const { addresses, abis } = _contracts;
  const charity = new ethers.Contract(addresses.charity_contract, abis.charity_abi, signerOrProvider);
  const coin    = new ethers.Contract(addresses.coin_contract,    abis.coin_abi,    signerOrProvider);
  return { charity, coin, addresses };
};

export const fetchAllCampaigns = async () => {
  const provider = getProvider();
  const { charity } = await getContracts(provider);
  const count = Number(await charity.getCampaignCount());
  const campaigns = [];
  for (let i = 0; i < count; i++) {
    const [name, desc, target, raised] = await charity.getCampaign(i);
    campaigns.push({
      id: i, name, desc,
      target: ethers.formatEther(target),
      raised: ethers.formatEther(raised),
    });
  }
  return campaigns;
};

export const fetchBalances = async (address) => {
  const provider = getProvider();
  const { coin } = await getContracts(provider);
  const ethBal  = await provider.getBalance(address);
  const coinBal = await coin.balanceOf(address);
  return {
    eth:  parseFloat(ethers.formatEther(ethBal)).toFixed(4),
    dnc:  parseFloat(ethers.formatUnits(coinBal, 18)).toFixed(2),
  };
};

export const fetchUserName = async (address) => {
  const provider = getProvider();
  const { charity } = await getContracts(provider);
  return await charity.getUserName(address);
};

export const fetchIsRegistered = async (address) => {
  const provider = getProvider();
  const { charity } = await getContracts(provider);
  return await charity.isRegistered(address);
};

export const fetchAdmin = async () => {
  const provider = getProvider();
  const { charity } = await getContracts(provider);
  return await charity.getAdmin();
};

export const fetchIsPaused = async () => {
  const provider = getProvider();
  const { charity } = await getContracts(provider);
  return await charity.paused();
};

export const registerUser = async (signer, displayName) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.registerUser(displayName, { gasLimit: 200000 });
  return await tx.wait();
};

export const donateToCampaign = async (signer, campaignId, ethAmount) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.donate(campaignId, {
    value: ethers.parseEther(ethAmount.toString()),
    gasLimit: 300000,
  });
  return await tx.wait();
};

export const addCampaign = async (signer, name, desc, targetEth) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.addCampaign(name, desc, ethers.parseEther(targetEth.toString()), { gasLimit: 300000 });
  return await tx.wait();
};

export const updateCampaign = async (signer, id, name, desc, targetEth) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.updateCampaign(id, name, desc, ethers.parseEther(targetEth.toString()), { gasLimit: 300000 });
  return await tx.wait();
};

export const pauseContract = async (signer) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.pause({ gasLimit: 100000 });
  return await tx.wait();
};

export const resumeContract = async (signer) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.resume({ gasLimit: 100000 });
  return await tx.wait();
};

export const mintCoins = async (signer, to, amount) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.adminMint(to, ethers.parseUnits(amount.toString(), 18), { gasLimit: 200000 });
  return await tx.wait();
};

export const withdrawFunds = async (signer, campaignId, recipient) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.withdraw(campaignId, recipient, { gasLimit: 200000 });
  return await tx.wait();
};

export const transferOwnership = async (signer, newAdmin) => {
  const { charity } = await getContracts(signer);
  const tx = await charity.transferOwnership(newAdmin, { gasLimit: 100000 });
  return await tx.wait();
};

export const fetchActivityHistory = async (address) => {
  const provider = getProvider();
  const { addresses } = await getContracts(provider);
  const charityAddr = addresses.charity_contract.toLowerCase();
  const coinAddr    = addresses.coin_contract.toLowerCase();
  const latest      = await provider.getBlockNumber();
  const results     = [];
  const addrLower   = address.toLowerCase();

  for (let i = 0; i <= latest; i++) {
    const block = await provider.getBlock(i, false);
    if (!block || !block.transactions || block.transactions.length === 0) continue;

    for (const txHash of block.transactions) {
      let tx;
      try { tx = await provider.getTransaction(txHash); } catch { continue; }
      if (!tx) continue;

      const to   = (tx.to || '').toLowerCase();
      const from = (tx.from || '').toLowerCase();

      if ((from === addrLower || to === addrLower) && (to === charityAddr || to === coinAddr)) {
        results.push({
          block:     i,
          hash:      tx.hash,
          direction: from === addrLower ? 'SENT' : 'RCVD',
          to:        tx.to,
          value:     parseFloat(ethers.formatEther(tx.value || 0n)).toFixed(6),
        });
      }
    }
  }
  return results;
};
