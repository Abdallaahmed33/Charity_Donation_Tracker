"""
balance_snapshot_exporter.py - Balance Snapshot Exporter
Charity Donation Tracker

Scans every account, reads their DNC coin balance and ETH balance,
and saves a timestamped CSV file.

    python balance_snapshot_exporter.py
"""

import csv
import json
from datetime import datetime
from web3 import Web3

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

if not w3.is_connected():
    print("❌  Cannot connect to Ganache.")
    exit(1)

# ── Load contracts ─────────────────────────────────────────────────────────────
try:
    with open("deployed_addresses.json") as f:
        addresses = json.load(f)
    with open("contract_abis.json") as f:
        abis = json.load(f)
except FileNotFoundError:
    print("❌  deployed_addresses.json / contract_abis.json not found.")
    print("    Run auto_setup.py first.")
    exit(1)

coin = w3.eth.contract(
    address=Web3.to_checksum_address(addresses["coin_contract"]),
    abi=abis["coin_abi"]
)

charity = w3.eth.contract(
    address=Web3.to_checksum_address(addresses["charity_contract"]),
    abi=abis["charity_abi"]
)


def get_display_name(address: str) -> str:
    try:
        name = charity.functions.getUserName(address).call()
        return name if name else "(not registered)"
    except Exception:
        return "(unknown)"


# ── Build snapshot ─────────────────────────────────────────────────────────────
print("\n📸  Building balance snapshot …")

accounts   = w3.eth.accounts
rows       = []

for acc in accounts:
    checksum  = Web3.to_checksum_address(acc)
    eth_bal   = float(w3.from_wei(w3.eth.get_balance(checksum), "ether"))
    raw_coin  = coin.functions.balanceOf(checksum).call()
    coin_bal  = raw_coin / (10 ** 18)
    name      = get_display_name(checksum)
    rows.append((checksum, name, coin_bal, eth_bal))
    print(f"    {checksum}  DNC: {coin_bal:>16,.4f}   ETH: {eth_bal:.6f}")

# ── Write CSV ──────────────────────────────────────────────────────────────────
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename  = f"balance_snapshot_{timestamp}.csv"

with open(filename, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Account Address", "Display Name", "Donor Coin Balance", "ETH Balance"])
    for row in rows:
        writer.writerow(row)

print(f"\n✅  Snapshot saved to:  {filename}")
print(f"    Accounts exported : {len(rows)}")
