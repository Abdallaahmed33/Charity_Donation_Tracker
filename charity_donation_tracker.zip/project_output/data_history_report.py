"""
data_history_report.py - Data History Report
Charity Donation Tracker

Reads the blockchain history and prints a clean text table showing
how much ETH each charity campaign has raised.

Run:
    python data_history_report.py
"""

import json
from collections import defaultdict
from web3 import Web3

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

# ── Load contracts ─────────────────────────────────────────────────────────────
try:
    with open("deployed_addresses.json") as f:
        addresses = json.load(f)
    with open("contract_abis.json") as f:
        abis = json.load(f)
except FileNotFoundError:
    print("❌  deployed_addresses.json / contract_abis.json not found.")
    print("    Run auto_setup.py first.")
    exit(1)

CHARITY_ADDRESS = Web3.to_checksum_address(addresses["charity_contract"])
charity = w3.eth.contract(address=CHARITY_ADDRESS, abi=abis["charity_abi"])

# donate(uint256) selector
DONATE_SELECTOR = w3.keccak(text="donate(uint256)").hex()[:10]


def wei_to_eth(wei_val: int) -> float:
    return float(w3.from_wei(wei_val, "ether"))


def extract_campaign_id(input_data) -> int | None:
    if isinstance(input_data, (bytes, bytearray)):
        raw = input_data
    else:
        raw = bytes.fromhex(str(input_data).replace("0x", ""))
    if len(raw) < 36:
        return None
    return int.from_bytes(raw[4:36], "big")


def run_history_report() -> None:
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║   CHARITY DONATION TRACKER — DATA HISTORY REPORT    ║")
    print("╚══════════════════════════════════════════════════════╝")

    if not w3.is_connected():
        print("❌  Cannot connect to Ganache.")
        return

    # ── Load campaign names ────────────────────────────────────────────────────
    try:
        total = charity.functions.getCampaignCount().call()
    except Exception as e:
        print(f"  ❌ Could not read campaign count: {e}")
        return

    campaign_info = {}
    for cid in range(total):
        try:
            name, desc, target, raised = charity.functions.getCampaign(cid).call()
            campaign_info[cid] = {"name": name, "target": target, "raised_contract": raised}
        except Exception:
            campaign_info[cid] = {"name": f"Campaign #{cid}", "target": 0, "raised_contract": 0}

    # ── Scan blocks for donate() transactions ─────────────────────────────────
    latest_block  = w3.eth.block_number
    charity_lower = CHARITY_ADDRESS.lower()
    donations     = defaultdict(lambda: {"count": 0, "total_wei": 0})

    print(f"\n  Scanning blocks 0 → {latest_block} …", end="", flush=True)

    for block_num in range(0, latest_block + 1):
        block = w3.eth.get_block(block_num, full_transactions=True)
        for tx in block.transactions:
            to_addr = (tx.get("to") or "").lower()
            if to_addr != charity_lower:
                continue
            inp = tx.get("input", b"")
            if isinstance(inp, (bytes, bytearray)):
                selector = "0x" + inp[:4].hex() if len(inp) >= 4 else ""
            else:
                selector = str(inp)[:10]
            if selector.lower() == DONATE_SELECTOR.lower():
                cid = extract_campaign_id(inp)
                if cid is not None:
                    donations[cid]["count"]     += 1
                    donations[cid]["total_wei"] += tx["value"]

    print(" done.\n")

    # ── Print table ────────────────────────────────────────────────────────────
    col_id    = 5
    col_name  = 28
    col_cnt   = 10
    col_raised = 15
    col_goal   = 12
    col_pct    = 10

    header = (
        f"  {'ID':<{col_id}} "
        f"{'Campaign Name':<{col_name}} "
        f"{'Donations':>{col_cnt}} "
        f"{'ETH Raised':>{col_raised}} "
        f"{'Goal (ETH)':>{col_goal}} "
        f"{'Progress':>{col_pct}}"
    )
    sep = "  " + "─" * (col_id + col_name + col_cnt + col_raised + col_goal + col_pct + 10)

    print(header)
    print(sep)

    grand_total = 0.0
    for cid in range(total):
        info      = campaign_info[cid]
        data      = donations[cid]
        raised    = wei_to_eth(data["total_wei"])
        goal      = wei_to_eth(info["target"])
        grand_total += raised
        pct       = f"{raised / goal * 100:.0f}%" if goal > 0 else "N/A"
        bar       = "█" * int(raised / goal * 10) + "░" * (10 - int(raised / goal * 10)) if goal > 0 else "░" * 10
        print(
            f"  {cid:<{col_id}} "
            f"{info['name']:<{col_name}} "
            f"{data['count']:>{col_cnt}} "
            f"{raised:>{col_raised}.6f} "
            f"{goal:>{col_goal}.4f} "
            f"  {bar} {pct}"
        )

    print(sep)
    print(f"  {'TOTAL':<{col_id + col_name + col_cnt + 2}} {grand_total:>{col_raised}.6f} ETH raised across all campaigns")
    print(f"\n  Campaigns scanned : {total}")
    print(f"  Blocks scanned    : {latest_block + 1}")
    print(f"  Grand total ETH   : {grand_total:.6f}\n")


if __name__ == "__main__":
    run_history_report()
