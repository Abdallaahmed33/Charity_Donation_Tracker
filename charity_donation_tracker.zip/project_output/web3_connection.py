"""
web3_connection.py - Shared Web3 Helper
Charity Donation Tracker
"""

from web3 import Web3

GANACHE_URL = "http://127.0.0.1:7545"

w3 = Web3(Web3.HTTPProvider(GANACHE_URL))


def get_connection():
    """Return the active Web3 instance and verify connection."""
    if not w3.is_connected():
        raise ConnectionError(
            "❌  Cannot connect to Ganache.\n"
            "    Make sure Ganache is running on port 7545."
        )
    return w3


def wei_to_eth(wei_val: int) -> float:
    return float(w3.from_wei(wei_val, "ether"))


def eth_to_wei(eth_val: float) -> int:
    return w3.to_wei(eth_val, "ether")
