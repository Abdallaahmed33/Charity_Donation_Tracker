"""
personal_activity_history.py - Personal Activity History
Charity Donation Tracker

Asks the user for an address, scans every block, and prints a clean table
of every action that address has performed on the charity or coin contracts.

Can be imported and called from terminal_app.py, or run standalone:
    python personal_activity_history.py
"""

import json
from web3 import Web3

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

# ── Load addresses ─────────────────────────────────────────────────────────────
try:
    with open("deployed_addresses.json") as f:
        _addresses = json.load(f)
    CHARITY_CONTRACT_ADDRESS = Web3.to_checksum_address(_addresses["charity_contract"])
    COIN_CONTRACT_ADDRESS    = Web3.to_checksum_address(_addresses["coin_contract"])
except FileNotFoundError:
    CHARITY_CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000001"
    COIN_CONTRACT_ADDRESS    = "0x0000000000000000000000000000000000000002"

# ── Map 4-byte function selectors → human-readable action names ────────────────
SELECTOR_MAP = {
    w3.keccak(text="donate(uint256)").hex()[:10]:                               "Donate to Campaign",
    w3.keccak(text="registerUser(string)").hex()[:10]:                          "Register User",
    w3.keccak(text="addCampaign(string,string,uint256)").hex()[:10]:            "Add Campaign (Admin)",
    w3.keccak(text="updateCampaign(uint256,string,string,uint256)").hex()[:10]: "Update Campaign (Admin)",
    w3.keccak(text="pause()").hex()[:10]:                                       "Pause Contract (Admin)",
    w3.keccak(text="resume()").hex()[:10]:                                      "Resume Contract (Admin)",
    w3.keccak(text="transferOwnership(address)").hex()[:10]:                    "Transfer Ownership (Admin)",
    w3.keccak(text="withdraw(uint256,address)").hex()[:10]:                     "Withdraw Funds (Admin)",
    w3.keccak(text="mint(address,uint256)").hex()[:10]:                         "Mint Donor Coins (Admin)",
    w3.keccak(text="transfer(address,uint256)").hex()[:10]:                     "Transfer Donor Coins",
    w3.keccak(text="approve(address,uint256)").hex()[:10]:                      "Approve Coins",
}


def classify_action(tx: dict) -> str:
    data = tx.get("input", b"")
    if isinstance(data, (bytes, bytearray)):
        selector = "0x" + data[:4].hex() if len(data) >= 4 else ""
    else:
        selector = str(data)[:10]

    to_addr = (tx.get("to") or "").lower()
    if to_addr == CHARITY_CONTRACT_ADDRESS.lower():
        contract = "Charity"
    elif to_addr == COIN_CONTRACT_ADDRESS.lower():
        contract = "Coin"
    else:
        contract = "Other"

    action = SELECTOR_MAP.get(selector.lower(), f"Unknown ({selector})")
    return f"[{contract}] {action}"


def wei_to_eth_str(wei_val: int) -> str:
    if wei_val == 0:
        return "—"
    return f"{w3.from_wei(wei_val, 'ether'):.6f} ETH"


def show_activity_history(target_address: str) -> None:
    target        = Web3.to_checksum_address(target_address)
    target_lower  = target.lower()
    charity_lower = CHARITY_CONTRACT_ADDRESS.lower()
    coin_lower    = COIN_CONTRACT_ADDRESS.lower()

    latest_block = w3.eth.block_number
    results = []

    print(f"\n  Scanning blocks 0 → {latest_block} for {target} …", end="", flush=True)

    for block_num in range(0, latest_block + 1):
        block = w3.eth.get_block(block_num, full_transactions=True)
        for tx in block.transactions:
            from_addr = tx["from"].lower()
            to_addr   = (tx.get("to") or "").lower()
            touches   = to_addr in (charity_lower, coin_lower)

            if from_addr == target_lower and touches:
                results.append((block_num, "SENT", classify_action(tx), tx["value"]))
            elif to_addr == target_lower and touches:
                results.append((block_num, "RCVD", "[Coin] Received Donor Coins", tx["value"]))

    print(" done.\n")

    if not results:
        print(f"  No activity found for {target}.\n")
        return

    col_block  = 10
    col_dir    = 6
    col_action = 40
    col_value  = 16

    header = (
        f"  {'Block':<{col_block}} "
        f"{'Dir':<{col_dir}} "
        f"{'Action':<{col_action}} "
        f"{'Value':>{col_value}}"
    )
    sep = "  " + "─" * (col_block + col_dir + col_action + col_value + 6)

    print(f"  Activity History for: {target}")
    print(header)
    print(sep)

    for (block_num, direction, action, value) in results:
        print(
            f"  {block_num:<{col_block}} "
            f"{direction:<{col_dir}} "
            f"{action:<{col_action}} "
            f"{wei_to_eth_str(value):>{col_value}}"
        )

    print(sep)
    print(f"  Total actions found: {len(results)}\n")


if __name__ == "__main__":
    if not w3.is_connected():
        print("❌  Cannot connect to Ganache.")
    else:
        addr_input = input("Enter wallet address to inspect: ").strip()
        try:
            show_activity_history(addr_input)
        except Exception as e:
            print(f"❌  Error: {e}")
