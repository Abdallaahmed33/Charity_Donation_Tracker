"""
terminal_app.py - Main Terminal Application
Charity Donation Tracker

Run this file to start the app:
    python terminal_app.py
"""

import os
import json
from web3 import Web3
from transaction_sender import (
    w3, charity, coin,
    get_all_campaigns, get_campaign, get_campaign_count,
    get_coin_balance, get_eth_balance, get_admin,
    is_registered, get_user_name, is_paused,
    register_user, donate,
    add_campaign, update_campaign, batch_add_campaigns,
    mint_coins, pause_contract, resume_contract,
    transfer_ownership, withdraw_funds,
)

# ── Config ─────────────────────────────────────────────────────────────────────
ADMIN_PASSWORD = "admin123"   # Change this to something secret!

# ── Helpers ────────────────────────────────────────────────────────────────────
def clear():
    os.system("cls" if os.name == "nt" else "clear")


def hr(char="═", width=60):
    print(char * width)


def header(wallet: str, name: str):
    clear()
    hr()
    print("  🌍  CHARITY DONATION TRACKER")
    hr()
    admin_addr = get_admin()
    is_admin   = wallet.lower() == admin_addr.lower()
    role       = "👑 ADMIN" if is_admin else "👤 User"
    display    = name if name else wallet[:10] + "..."
    print(f"  Wallet : {wallet}")
    print(f"  Name   : {display}   [{role}]")
    if is_paused():
        print("  ⚠️   CONTRACT IS CURRENTLY PAUSED")
    hr()


def pause():
    input("\n  Press Enter to continue...")


def get_private_key(wallet: str) -> str:
    """
    In a real app, private keys would be stored securely.
    For Ganache testing, accounts are unlocked and we can use eth.accounts.
    This helper returns a dummy key for unlocked Ganache accounts.
    """
    # For Ganache, transactions can be sent from unlocked accounts directly.
    # We store the key in a local file or let the user paste it.
    key_file = "wallet_keys.json"
    if os.path.exists(key_file):
        with open(key_file) as f:
            keys = json.load(f)
        if wallet.lower() in keys:
            return keys[wallet.lower()]

    print("\n  🔑  Enter your private key (from Ganache) to sign transactions:")
    print("     (Tip: Click the key icon next to your address in Ganache)")
    key = input("  > ").strip()

    # Save for this session
    keys = {}
    if os.path.exists(key_file):
        with open(key_file) as f:
            keys = json.load(f)
    keys[wallet.lower()] = key
    with open(key_file, "w") as f:
        json.dump(keys, f)

    return key


# ── Onboarding ─────────────────────────────────────────────────────────────────
def login() -> tuple:
    """Ask for wallet address, register if new. Returns (wallet, name, private_key)."""
    clear()
    hr()
    print("  🌍  CHARITY DONATION TRACKER")
    hr()
    print("  Welcome! Please enter your Ganache wallet address to continue.\n")
    wallet_raw = input("  Wallet address: ").strip()

    try:
        wallet = Web3.to_checksum_address(wallet_raw)
    except Exception:
        print("  ❌  Invalid address. Please try again.")
        input("  Press Enter...")
        return login()

    name = get_user_name(wallet)

    if not is_registered(wallet):
        print(f"\n  👋  Welcome, new user! Please choose a display name.")
        display_name = input("  Display name: ").strip()
        if not display_name:
            display_name = "Anonymous"

        private_key = get_private_key(wallet)
        try:
            register_user(wallet, private_key, display_name)
            name = display_name
            print(f"\n  ✅  Registered as '{name}'")
            input("  Press Enter to continue...")
        except Exception as e:
            print(f"\n  ⚠️  Could not register on-chain: {e}")
            print("     Continuing without registration...")
            name = display_name
            input("  Press Enter to continue...")
    else:
        private_key = get_private_key(wallet)

    return wallet, name, private_key


# ── User Menu ──────────────────────────────────────────────────────────────────
def view_campaigns():
    campaigns = get_all_campaigns()
    if not campaigns:
        print("\n  No campaigns found.")
        return

    print(f"\n  {'ID':<5} {'Name':<30} {'Raised (ETH)':>14} {'Goal (ETH)':>12} {'Progress':>10}")
    print("  " + "─" * 76)
    for c in campaigns:
        raised = c["raised"] / 10**18
        target = c["target"] / 10**18
        pct    = (raised / target * 100) if target > 0 else 0
        bar    = "█" * int(pct / 10) + "░" * (10 - int(pct / 10))
        print(f"  {c['id']:<5} {c['name']:<30} {raised:>14.4f} {target:>12.4f}  {bar} {pct:.0f}%")
        if c["desc"]:
            print(f"        {c['desc']}")


def donate_menu(wallet: str, private_key: str):
    view_campaigns()
    print()
    try:
        cid    = int(input("  Campaign ID to donate to: ").strip())
        amount = float(input("  ETH amount to donate:     ").strip())
    except ValueError:
        print("  ❌  Invalid input.")
        return

    if amount <= 0:
        print("  ❌  Amount must be greater than 0.")
        return

    print(f"\n  Sending {amount} ETH to campaign {cid} …")
    try:
        receipt = donate(wallet, private_key, cid, amount)
        print(f"  ✅  Donation confirmed!  Block: {receipt['blockNumber']}")
        new_bal = get_coin_balance(wallet)
        print(f"  🪙  Your new DNC balance: {new_bal:,.4f} DNC")
    except Exception as e:
        print(f"  ❌  Transaction failed: {e}")


def balance_checker():
    print("\n  Enter any wallet address to check balances.")
    addr_raw = input("  Address: ").strip()
    try:
        addr = Web3.to_checksum_address(addr_raw)
    except Exception:
        print("  ❌  Invalid address.")
        return

    eth_bal  = get_eth_balance(addr)
    coin_bal = get_coin_balance(addr)
    name     = get_user_name(addr) or "(not registered)"

    print(f"\n  ╔══════════════════════════════════════════╗")
    print(f"  ║  Balance for: {addr[:20]}…   ║")
    print(f"  ╠══════════════════════════════════════════╣")
    print(f"  ║  Name        : {name:<26} ║")
    print(f"  ║  ETH Balance : {eth_bal:<26.6f} ║")
    print(f"  ║  DNC Balance : {coin_bal:<26,.4f} ║")
    print(f"  ╚══════════════════════════════════════════╝")


def activity_history():
    print("\n  Enter an address to view its activity history.")
    addr_raw = input("  Address (or Enter for your own): ").strip()
    if not addr_raw:
        return

    try:
        addr = Web3.to_checksum_address(addr_raw)
    except Exception:
        print("  ❌  Invalid address.")
        return

    from personal_activity_history import show_activity_history
    show_activity_history(addr)


# ── Admin Menu ─────────────────────────────────────────────────────────────────
def admin_add_campaign(wallet: str, private_key: str):
    print("\n  ── Add New Campaign ──")
    name   = input("  Campaign name        : ").strip()
    desc   = input("  Description          : ").strip()
    try:
        target = float(input("  Fundraising goal (ETH): ").strip())
    except ValueError:
        print("  ❌  Invalid amount.")
        return

    print(f"\n  Creating campaign '{name}' …")
    try:
        receipt = add_campaign(wallet, private_key, name, desc, target)
        print(f"  ✅  Campaign added!  Block: {receipt['blockNumber']}")
    except Exception as e:
        print(f"  ❌  Failed: {e}")


def admin_update_campaign(wallet: str, private_key: str):
    view_campaigns()
    print("\n  ── Update Campaign ──")
    try:
        cid    = int(input("  Campaign ID to update : ").strip())
        c      = get_campaign(cid)
        print(f"  Current name  : {c['name']}")
        print(f"  Current desc  : {c['desc']}")
        print(f"  Current target: {c['target'] / 10**18} ETH")
        name   = input("  New name (Enter to keep): ").strip() or c["name"]
        desc   = input("  New desc (Enter to keep): ").strip() or c["desc"]
        target = input("  New goal in ETH (Enter to keep): ").strip()
        target = float(target) if target else c["target"] / 10**18
    except (ValueError, Exception) as e:
        print(f"  ❌  Error: {e}")
        return

    try:
        receipt = update_campaign(wallet, private_key, cid, name, desc, target)
        print(f"  ✅  Campaign updated!  Block: {receipt['blockNumber']}")
    except Exception as e:
        print(f"  ❌  Failed: {e}")


def admin_batch_add(wallet: str, private_key: str):
    print("\n  ── Batch Add Campaigns ──")
    print("  Enter campaigns one by one. Type 'done' as name when finished.\n")
    names, descs, targets = [], [], []
    while True:
        name = input(f"  Campaign {len(names)+1} name (or 'done'): ").strip()
        if name.lower() == "done":
            break
        desc   = input("  Description          : ").strip()
        try:
            target = float(input("  Goal (ETH)           : ").strip())
        except ValueError:
            print("  ❌  Invalid amount, skipping.")
            continue
        names.append(name)
        descs.append(desc)
        targets.append(target)

    if not names:
        print("  No campaigns entered.")
        return

    print(f"\n  Adding {len(names)} campaigns in one transaction …")
    try:
        receipt = batch_add_campaigns(wallet, private_key, names, descs, targets)
        print(f"  ✅  {len(names)} campaigns added!  Block: {receipt['blockNumber']}")
    except Exception as e:
        print(f"  ❌  Failed: {e}")


def admin_mint_coins(wallet: str, private_key: str):
    print("\n  ── Mint Donor Coins ──")
    to_addr = input("  Recipient address : ").strip()
    try:
        amount  = float(input("  Amount (DNC)      : ").strip())
    except ValueError:
        print("  ❌  Invalid amount.")
        return

    print(f"\n  Minting {amount} DNC to {to_addr} …")
    try:
        receipt = mint_coins(wallet, private_key, to_addr, amount)
        print(f"  ✅  Minted!  Block: {receipt['blockNumber']}")
    except Exception as e:
        print(f"  ❌  Failed: {e}")


def admin_pause_resume(wallet: str, private_key: str):
    paused = is_paused()
    if paused:
        confirm = input("  Contract is PAUSED. Resume it? (y/n): ").strip().lower()
        if confirm == "y":
            try:
                resume_contract(wallet, private_key)
                print("  ✅  Contract RESUMED.")
            except Exception as e:
                print(f"  ❌  Failed: {e}")
    else:
        confirm = input("  Contract is ACTIVE. Pause it? (y/n): ").strip().lower()
        if confirm == "y":
            try:
                pause_contract(wallet, private_key)
                print("  ✅  Contract PAUSED.")
            except Exception as e:
                print(f"  ❌  Failed: {e}")


def admin_transfer_ownership(wallet: str, private_key: str):
    print("\n  ── Transfer Ownership ──")
    print(f"  Current admin: {get_admin()}")
    new_admin = input("  New admin address   : ").strip()
    confirm   = input(f"  Transfer admin to {new_admin[:12]}…? (yes/no): ").strip().lower()
    if confirm != "yes":
        print("  Cancelled.")
        return
    try:
        receipt = transfer_ownership(wallet, private_key, new_admin)
        print(f"  ✅  Ownership transferred!  Block: {receipt['blockNumber']}")
    except Exception as e:
        print(f"  ❌  Failed: {e}")


def admin_withdraw(wallet: str, private_key: str):
    view_campaigns()
    print("\n  ── Withdraw Campaign Funds ──")
    try:
        cid       = int(input("  Campaign ID to withdraw from : ").strip())
        recipient = input("  Recipient address            : ").strip()
    except ValueError:
        print("  ❌  Invalid input.")
        return

    c = get_campaign(cid)
    eth_raised = c["raised"] / 10**18
    print(f"\n  This will withdraw {eth_raised:.6f} ETH from '{c['name']}'.")
    confirm = input("  Confirm? (yes/no): ").strip().lower()
    if confirm != "yes":
        print("  Cancelled.")
        return
    try:
        receipt = withdraw_funds(wallet, private_key, cid, recipient)
        print(f"  ✅  {eth_raised:.6f} ETH withdrawn!  Block: {receipt['blockNumber']}")
    except Exception as e:
        print(f"  ❌  Failed: {e}")


def admin_menu(wallet: str, private_key: str, name: str):
    while True:
        header(wallet, name)
        print("  👑  ADMIN PANEL\n")
        print("  [1]  Add new campaign")
        print("  [2]  Update campaign")
        print("  [3]  Batch add campaigns")
        print("  [4]  Mint Donor Coins")
        print("  [5]  Pause / Resume contract")
        print("  [6]  Transfer ownership")
        print("  [7]  Withdraw campaign funds")
        print("  [0]  Back to user menu")
        hr("─")
        choice = input("  > ").strip()

        if   choice == "1": admin_add_campaign(wallet, private_key)
        elif choice == "2": admin_update_campaign(wallet, private_key)
        elif choice == "3": admin_batch_add(wallet, private_key)
        elif choice == "4": admin_mint_coins(wallet, private_key)
        elif choice == "5": admin_pause_resume(wallet, private_key)
        elif choice == "6": admin_transfer_ownership(wallet, private_key)
        elif choice == "7": admin_withdraw(wallet, private_key)
        elif choice == "0": break
        else: print("  ❌  Invalid option.")

        pause()


# ── Main Loop ──────────────────────────────────────────────────────────────────
def main():
    wallet, name, private_key = login()

    while True:
        header(wallet, name)
        print("  [1]  View all campaigns")
        print("  [2]  Donate to a campaign")
        print("  [3]  Check coin & ETH balance")
        print("  [4]  View my activity history")
        print("  [5]  View any address activity")
        print("  [9]  Admin menu  🔒")
        print("  [0]  Exit")
        hr("─")
        choice = input("  > ").strip()

        if choice == "1":
            header(wallet, name)
            view_campaigns()
            pause()

        elif choice == "2":
            header(wallet, name)
            donate_menu(wallet, private_key)
            pause()

        elif choice == "3":
            header(wallet, name)
            balance_checker()
            pause()

        elif choice == "4":
            header(wallet, name)
            from personal_activity_history import show_activity_history
            show_activity_history(wallet)
            pause()

        elif choice == "5":
            header(wallet, name)
            activity_history()
            pause()

        elif choice == "9":
            pwd = input("  🔑  Admin password: ").strip()
            if pwd == ADMIN_PASSWORD:
                admin_menu(wallet, private_key, name)
            else:
                print("  ❌  Wrong password.")
                pause()

        elif choice == "0":
            print("\n  👋  Goodbye!\n")
            break

        else:
            print("  ❌  Invalid option.")
            pause()


if __name__ == "__main__":
    main()
