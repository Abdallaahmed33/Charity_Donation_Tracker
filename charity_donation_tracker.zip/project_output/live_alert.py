"""
live_alert.py - Live Donation Alert System
Charity Donation Tracker

Run in a separate terminal window. Polls the blockchain for
new blocks and prints an alert whenever a donation is detected.

    python live_alert.py
"""

import time
import json
from web3 import Web3

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

if not w3.is_connected():
    print("❌  Cannot connect to Ganache. Make sure it is running on port 7545.")
    exit(1)

# ── Load deployed address ──────────────────────────────────────────────────────
try:
    with open("deployed_addresses.json") as f:
        addresses = json.load(f)
    CHARITY_ADDRESS = Web3.to_checksum_address(addresses["charity_contract"])
except FileNotFoundError:
    print("❌  deployed_addresses.json not found. Run auto_setup.py first.")
    exit(1)

# ── donate(uint256) selector: keccak256("donate(uint256)")[:4] ─────────────────
DONATE_SELECTOR = w3.keccak(text="donate(uint256)").hex()[:10]

# ── Polling ────────────────────────────────────────────────────────────────────
print("🔔  Live Alert System started — watching for donations …")
print(f"    Contract  : {CHARITY_ADDRESS}")
print(f"    Selector  : {DONATE_SELECTOR}")
print("    Press Ctrl+C to stop.\n")

last_block = w3.eth.block_number
charity_lower = CHARITY_ADDRESS.lower()

while True:
    try:
        current_block = w3.eth.block_number

        if current_block > last_block:
            for block_num in range(last_block + 1, current_block + 1):
                block = w3.eth.get_block(block_num, full_transactions=True)
                for tx in block.transactions:
                    to_addr = (tx.get("to") or "").lower()
                    if to_addr != charity_lower:
                        continue

                    input_data = tx.get("input", b"")
                    if isinstance(input_data, (bytes, bytearray)):
                        selector = "0x" + input_data[:4].hex() if len(input_data) >= 4 else ""
                    else:
                        selector = str(input_data)[:10]

                    if selector.lower() == DONATE_SELECTOR.lower():
                        eth_val = float(w3.from_wei(tx["value"], "ether"))
                        donor   = tx["from"]
                        print(
                            f"  🚨  ALERT: A new donation just happened!\n"
                            f"       Donor   : {donor}\n"
                            f"       Amount  : {eth_val:.6f} ETH\n"
                            f"       Block   : {block_num}\n"
                            f"       Tx Hash : {tx['hash'].hex()}\n"
                        )

            last_block = current_block

        time.sleep(2)   # poll every 2 seconds

    except KeyboardInterrupt:
        print("\n\n  🛑  Alert system stopped.")
        break
    except Exception as e:
        print(f"  ⚠️  Error polling block {last_block}: {e}")
        time.sleep(5)
