"""
admin_dashboard.py - Admin Dashboard Script
Charity Donation Tracker

Prints a full system summary:
  - Total charity campaigns stored in the contract
  - Total Donor Coins minted
  - Total transactions on the contract
  - Top 3 most active user addresses

Run:
    python admin_dashboard.py
"""

import json
from web3 import Web3

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

# ── Load contracts ─────────────────────────────────────────────────────────────
try:
    with open("deployed_addresses.json") as f:
        addresses = json.load(f)
    with open("contract_abis.json") as f:
        abis = json.load(f)
except FileNotFoundError:
    print("❌  deployed_addresses.json / contract_abis.json not found.")
    print("    Run auto_setup.py first.")
    exit(1)

CHARITY_ADDRESS = Web3.to_checksum_address(addresses["charity_contract"])
COIN_ADDRESS    = Web3.to_checksum_address(addresses["coin_contract"])

charity = w3.eth.contract(address=CHARITY_ADDRESS, abi=abis["charity_abi"])
coin    = w3.eth.contract(address=COIN_ADDRESS,    abi=abis["coin_abi"])


def section(title: str) -> None:
    print(f"\n{'═' * 56}")
    print(f"  {title}")
    print(f"{'═' * 56}")


def run_dashboard() -> None:
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║    CHARITY DONATION TRACKER — ADMIN DASHBOARD       ║")
    print("╚══════════════════════════════════════════════════════╝")

    if not w3.is_connected():
        print("❌  Cannot connect to Ganache. Make sure it is running on port 7545.")
        return

    # ── 1. Total campaigns ────────────────────────────────────────────────────
    section("1. CHARITY CAMPAIGNS")
    try:
        total_campaigns = charity.functions.getCampaignCount().call()
        print(f"  Total campaigns stored : {total_campaigns}")

        print(f"\n  {'ID':<5} {'Name':<30} {'Raised (ETH)':>14} {'Goal (ETH)':>12}")
        print("  " + "─" * 65)
        for i in range(total_campaigns):
            name, desc, target, raised = charity.functions.getCampaign(i).call()
            r_eth = raised / 10**18
            t_eth = target / 10**18
            print(f"  {i:<5} {name:<30} {r_eth:>14.4f} {t_eth:>12.4f}")
    except Exception as e:
        print(f"  Could not read campaigns: {e}")
        total_campaigns = 0

    # ── 2. Total Donor Coins minted ───────────────────────────────────────────
    section("2. DONOR COIN SUPPLY")
    try:
        raw_supply    = coin.functions.totalSupply().call()
        human_supply  = raw_supply / (10 ** 18)
        print(f"  Total Donor Coins minted : {human_supply:,.4f} DNC")
    except Exception as e:
        print(f"  Could not read coin supply: {e}")

    # ── 3 & 4. Scan blocks → count tx per sender ──────────────────────────────
    section("3. TRANSACTION COUNT & TOP USERS")

    latest_block  = w3.eth.block_number
    tx_count      = 0
    sender_counts = {}

    charity_lower = CHARITY_ADDRESS.lower()
    coin_lower    = COIN_ADDRESS.lower()

    print(f"  Scanning blocks 0 → {latest_block} …", end="", flush=True)

    for block_num in range(0, latest_block + 1):
        block = w3.eth.get_block(block_num, full_transactions=True)
        for tx in block.transactions:
            to_addr = (tx["to"] or "").lower()
            if to_addr in (charity_lower, coin_lower):
                tx_count += 1
                sender = tx["from"]
                sender_counts[sender] = sender_counts.get(sender, 0) + 1

    print(" done.")
    print(f"\n  Total transactions on contracts : {tx_count}")

    if sender_counts:
        sorted_senders = sorted(sender_counts.items(), key=lambda x: x[1], reverse=True)
        top3 = sorted_senders[:3]
        print(f"\n  {'Rank':<6} {'Address':<44} {'Tx Count':>8}")
        print(f"  {'─'*6} {'─'*44} {'─'*8}")
        for rank, (addr, count) in enumerate(top3, start=1):
            try:
                name = charity.functions.getUserName(addr).call() or "(no name)"
            except Exception:
                name = "(unknown)"
            print(f"  #{rank:<5} {addr:<44} {count:>8}   {name}")
    else:
        print("  No contract transactions found yet.")

    print(f"\n{'═' * 56}")
    print("  Dashboard complete.")
    print(f"{'═' * 56}\n")


if __name__ == "__main__":
    run_dashboard()
