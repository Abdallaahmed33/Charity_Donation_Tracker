"""
security_test.py - Automated Security Tests
Charity Donation Tracker

Proves that a Normal User gets an error if they attempt admin actions.
Prints PASS / FAIL for each test.

    python security_test.py
"""

import json
from web3 import Web3
from web3.exceptions import ContractLogicError

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

if not w3.is_connected():
    print("❌  Cannot connect to Ganache.")
    exit(1)

try:
    with open("deployed_addresses.json") as f:
        addresses = json.load(f)
    with open("contract_abis.json") as f:
        abis = json.load(f)
except FileNotFoundError:
    print("❌  Run auto_setup.py first.")
    exit(1)

charity = w3.eth.contract(
    address=Web3.to_checksum_address(addresses["charity_contract"]),
    abi=abis["charity_abi"]
)
coin = w3.eth.contract(
    address=Web3.to_checksum_address(addresses["coin_contract"]),
    abi=abis["coin_abi"]
)

ADMIN        = Web3.to_checksum_address(addresses["admin"])
NORMAL_USER  = Web3.to_checksum_address(w3.eth.accounts[5])  # not admin

results = []

def run_test(description: str, should_revert: bool, fn):
    reverted = False
    try:
        fn()
    except (ContractLogicError, Exception) as e:
        err = str(e).lower()
        if "revert" in err or "only admin" in err or "not admin" in err or "execution reverted" in err:
            reverted = True

    passed = (reverted == should_revert)
    status = "✅ PASS" if passed else "❌ FAIL"
    results.append((description, status))
    print(f"  {status}  {description}")


print("\n" + "═" * 64)
print("  CHARITY DONATION TRACKER — SECURITY TEST SUITE")
print("═" * 64)
print(f"  Admin       : {ADMIN}")
print(f"  Normal user : {NORMAL_USER}")
print("─" * 64)

# ── Test 1: Normal user tries to add a campaign (should revert) ────────────────
run_test(
    "Normal user cannot add a campaign",
    should_revert=True,
    fn=lambda: charity.functions.addCampaign(
        "Hack Campaign", "Malicious", w3.to_wei(1, "ether")
    ).transact({"from": NORMAL_USER, "gas": 300_000})
)

# ── Test 2: Normal user tries to update a campaign (should revert) ─────────────
run_test(
    "Normal user cannot update a campaign",
    should_revert=True,
    fn=lambda: charity.functions.updateCampaign(
        0, "Hacked", "Hacked desc", w3.to_wei(1, "ether")
    ).transact({"from": NORMAL_USER, "gas": 300_000})
)

# ── Test 3: Normal user tries to pause (should revert) ────────────────────────
run_test(
    "Normal user cannot pause the contract",
    should_revert=True,
    fn=lambda: charity.functions.pause().transact({"from": NORMAL_USER, "gas": 100_000})
)

# ── Test 4: Normal user tries to transfer ownership (should revert) ────────────
run_test(
    "Normal user cannot transfer ownership",
    should_revert=True,
    fn=lambda: charity.functions.transferOwnership(NORMAL_USER).transact(
        {"from": NORMAL_USER, "gas": 100_000}
    )
)

# ── Test 5: Normal user tries to mint coins (should revert) ───────────────────
run_test(
    "Normal user cannot mint Donor Coins",
    should_revert=True,
    fn=lambda: coin.functions.mint(NORMAL_USER, 1000).transact(
        {"from": NORMAL_USER, "gas": 100_000}
    )
)

# ── Test 6: Normal user CAN donate (should NOT revert) ────────────────────────
run_test(
    "Normal user CAN donate to a campaign",
    should_revert=False,
    fn=lambda: charity.functions.donate(0).transact({
        "from":  NORMAL_USER,
        "value": w3.to_wei(0.01, "ether"),
        "gas":   200_000
    })
)

# ── Test 7: Normal user CAN register (should NOT revert) ──────────────────────
# Use a fresh account to avoid "Already registered"
fresh_user = Web3.to_checksum_address(w3.eth.accounts[8])
run_test(
    "Normal user CAN register a display name",
    should_revert=False,
    fn=lambda: charity.functions.registerUser("TestUser").transact(
        {"from": fresh_user, "gas": 200_000}
    )
)

# ── Summary ────────────────────────────────────────────────────────────────────
print("─" * 64)
passed_count = sum(1 for _, s in results if "PASS" in s)
total_count  = len(results)
print(f"\n  Result: {passed_count}/{total_count} tests passed\n")

if passed_count == total_count:
    print("  🎉  All security tests PASSED!")
else:
    print("  ⚠️   Some tests FAILED — review the contract's access control.")

print()
