// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IDonorCoin {
    function mint(address to, uint amount) external;
}

contract CharityTracker {

    struct Campaign {
        string name;
        string description;
        uint   target;
        uint   totalDonated;
        bool   exists;
    }

    address    public admin;
    bool       public paused;
    IDonorCoin public donorCoin;

    Campaign[] public campaigns;

    mapping(address => string) public userNames;
    mapping(address => bool)   public registered;

    event Donated(address indexed donor, uint indexed campaignId, uint amount);
    event CampaignAdded(uint indexed id, string name);
    event CampaignUpdated(uint indexed id, string name);
    event UserRegistered(address indexed user, string name);
    event FundsWithdrawn(uint indexed campaignId, address recipient, uint amount);
    event OwnershipTransferred(address indexed oldAdmin, address indexed newAdmin);

    modifier onlyOwner() {
        require(msg.sender == admin, "Only admin can call this");
        _;
    }

    modifier whenNotPaused() {
        require(!paused, "Contract is paused");
        _;
    }

    constructor(address coinAddress) {
        admin     = msg.sender;
        donorCoin = IDonorCoin(coinAddress);
    }

    function addCampaign(string memory _name, string memory _desc, uint _target) public onlyOwner {
        require(bytes(_name).length > 0, "Name cannot be empty");
        require(_target > 0, "Target must be > 0");
        campaigns.push(Campaign(_name, _desc, _target, 0, true));
        emit CampaignAdded(campaigns.length - 1, _name);
    }

    function updateCampaign(uint id, string memory _name, string memory _desc, uint _target) public onlyOwner {
        require(id < campaigns.length, "Invalid campaign ID");
        require(_target > 0, "Target must be > 0");
        campaigns[id].name        = _name;
        campaigns[id].description = _desc;
        campaigns[id].target      = _target;
        emit CampaignUpdated(id, _name);
    }

    function batchAddCampaigns(string[] memory names, string[] memory descs, uint[] memory targets) public onlyOwner {
        require(names.length == descs.length && descs.length == targets.length, "Array length mismatch");
        for (uint i = 0; i < names.length; i++) {
            require(targets[i] > 0, "Target must be > 0");
            campaigns.push(Campaign(names[i], descs[i], targets[i], 0, true));
            emit CampaignAdded(campaigns.length - 1, names[i]);
        }
    }

    function batchUpdateCampaigns(uint[] memory ids, string[] memory names, string[] memory descs, uint[] memory targets) public onlyOwner {
        require(ids.length == names.length && names.length == targets.length, "Array length mismatch");
        for (uint i = 0; i < ids.length; i++) {
            require(ids[i] < campaigns.length, "Invalid campaign ID");
            require(targets[i] > 0, "Target must be > 0");
            campaigns[ids[i]].name        = names[i];
            campaigns[ids[i]].description = descs[i];
            campaigns[ids[i]].target      = targets[i];
        }
    }

    function pause()  public onlyOwner { paused = true;  }
    function resume() public onlyOwner { paused = false; }

    function transferOwnership(address newAdmin) public onlyOwner {
        require(newAdmin != address(0), "Invalid address");
        emit OwnershipTransferred(admin, newAdmin);
        admin = newAdmin;
    }

    function withdraw(uint campaignId, address payable recipient) public onlyOwner {
        require(campaignId < campaigns.length, "Invalid campaign ID");
        uint amount = campaigns[campaignId].totalDonated;
        require(amount > 0, "Nothing to withdraw");
        campaigns[campaignId].totalDonated = 0;
        recipient.transfer(amount);
        emit FundsWithdrawn(campaignId, recipient, amount);
    }

    function registerUser(string memory displayName) public {
        require(!registered[msg.sender], "Already registered");
        require(bytes(displayName).length > 0, "Name cannot be empty");
        userNames[msg.sender]  = displayName;
        registered[msg.sender] = true;
        emit UserRegistered(msg.sender, displayName);
    }

    function donate(uint campaignId) public payable whenNotPaused {
        require(campaignId < campaigns.length, "Invalid campaign ID");
        require(msg.value > 0, "Must send ETH");
        campaigns[campaignId].totalDonated += msg.value;
        donorCoin.mint(msg.sender, msg.value * 100);
        emit Donated(msg.sender, campaignId, msg.value);
    }

    function getCampaign(uint id) public view returns (string memory, string memory, uint, uint) {
        require(id < campaigns.length, "Invalid campaign ID");
        Campaign memory c = campaigns[id];
        return (c.name, c.description, c.target, c.totalDonated);
    }

    function getCampaignCount() public view returns (uint) { return campaigns.length; }
    function getAdmin()         public view returns (address) { return admin; }
    function getUserName(address user) public view returns (string memory) { return userNames[user]; }
    function isRegistered(address user) public view returns (bool) { return registered[user]; }
}
