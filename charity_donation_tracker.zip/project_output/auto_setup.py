"""
auto_setup.py - Auto Deploy & Seed Script
Charity Donation Tracker

Deploys CharityTracker.sol + DonorCoin.sol to Ganache,
seeds 5 sample campaigns, mints 1,000,000 DNC to admin,
then saves contract addresses + ABIs to JSON files.

Run once before using the app:
    python auto_setup.py
"""

import json
from web3 import Web3
from solcx import compile_standard, install_solc

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

if not w3.is_connected():
    print("❌  Cannot connect to Ganache. Make sure it is running on port 7545.")
    exit(1)

print("✅  Connected to Ganache")

ADMIN_ACCOUNT = w3.eth.accounts[0]
print(f"    Admin account : {ADMIN_ACCOUNT}")

# ── Solidity source ────────────────────────────────────────────────────────────
DONOR_COIN_SOURCE = """
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DonorCoin {

    string public name = "Donor Coin";
    string public symbol = "DNC";
    uint public totalSupply;
    uint8 public decimals = 18;

    address public admin;

    mapping(address => uint) public balanceOf;
    mapping(address => mapping(address => uint)) public allowance;

    event Transfer(address indexed from, address indexed to, uint amount);
    event Approval(address indexed owner, address indexed spender, uint amount);

    constructor(address _admin) {
        admin = _admin;
    }

    modifier onlyOwner() {
        require(msg.sender == admin, "Not admin");
        _;
    }

    function transferOwnership(address newAdmin) public onlyOwner {
        require(newAdmin != address(0), "Invalid address");
        admin = newAdmin;
    }

    function mint(address to, uint amount) public onlyOwner {
        balanceOf[to] += amount;
        totalSupply     += amount;
        emit Transfer(address(0), to, amount);
    }

    function transfer(address to, uint amount) public returns (bool) {
        require(balanceOf[msg.sender] >= amount, "Not enough balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]          += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint amount) public returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint amount) public returns (bool) {
        require(balanceOf[from] >= amount, "Not enough balance");
        require(allowance[from][msg.sender] >= amount, "Not approved");
        balanceOf[from]             -= amount;
        balanceOf[to]               += amount;
        allowance[from][msg.sender] -= amount;
        emit Transfer(from, to, amount);
        return true;
    }
}
"""

CHARITY_TRACKER_SOURCE = """
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IDonorCoin {
    function mint(address to, uint amount) external;
}

contract CharityTracker {

    struct Campaign {
        string name;
        string description;
        uint   target;
        uint   totalDonated;
        bool   exists;
    }

    address    public admin;
    bool       public paused;
    IDonorCoin public donorCoin;

    Campaign[] public campaigns;

    mapping(address => string) public userNames;
    mapping(address => bool)   public registered;

    event Donated(address indexed donor, uint indexed campaignId, uint amount);
    event CampaignAdded(uint indexed id, string name);
    event UserRegistered(address indexed user, string name);
    event FundsWithdrawn(uint indexed campaignId, address recipient, uint amount);

    constructor(address coinAddress) {
        admin     = msg.sender;
        donorCoin = IDonorCoin(coinAddress);
    }

    modifier onlyOwner() {
        require(msg.sender == admin, "Only admin can call this");
        _;
    }

    modifier whenNotPaused() {
        require(!paused, "Contract is paused");
        _;
    }

    // ── Admin functions ──────────────────────────────────────────────────────

    function addCampaign(string memory _name, string memory _desc, uint _target)
        public onlyOwner
    {
        require(_target > 0, "Target must be > 0");
        campaigns.push(Campaign(_name, _desc, _target, 0, true));
        emit CampaignAdded(campaigns.length - 1, _name);
    }

    function updateCampaign(uint id, string memory _name, string memory _desc, uint _target)
        public onlyOwner
    {
        require(id < campaigns.length, "Invalid campaign ID");
        require(_target > 0, "Target must be > 0");
        campaigns[id].name        = _name;
        campaigns[id].description = _desc;
        campaigns[id].target      = _target;
    }

    function batchAddCampaigns(
        string[] memory names,
        string[] memory descs,
        uint[]   memory targets
    ) public onlyOwner {
        require(names.length == descs.length && descs.length == targets.length, "Array length mismatch");
        for (uint i = 0; i < names.length; i++) {
            require(targets[i] > 0, "Target must be > 0");
            campaigns.push(Campaign(names[i], descs[i], targets[i], 0, true));
            emit CampaignAdded(campaigns.length - 1, names[i]);
        }
    }

    function batchUpdateCampaigns(
        uint[]   memory ids,
        string[] memory names,
        string[] memory descs,
        uint[]   memory targets
    ) public onlyOwner {
        require(ids.length == names.length && names.length == targets.length, "Array length mismatch");
        for (uint i = 0; i < ids.length; i++) {
            require(ids[i] < campaigns.length, "Invalid campaign ID");
            require(targets[i] > 0, "Target must be > 0");
            campaigns[ids[i]].name        = names[i];
            campaigns[ids[i]].description = descs[i];
            campaigns[ids[i]].target      = targets[i];
        }
    }

    function pause()  public onlyOwner { paused = true;  }
    function resume() public onlyOwner { paused = false; }

    function adminMint(address to, uint amount) public onlyOwner {
        donorCoin.mint(to, amount);
    }

    function transferOwnership(address newAdmin) public onlyOwner {
        require(newAdmin != address(0), "Invalid address");
        admin = newAdmin;
    }

    function withdraw(uint campaignId, address payable recipient) public onlyOwner {
        require(campaignId < campaigns.length, "Invalid campaign ID");
        uint amount = campaigns[campaignId].totalDonated;
        require(amount > 0, "Nothing to withdraw");
        campaigns[campaignId].totalDonated = 0;
        recipient.transfer(amount);
        emit FundsWithdrawn(campaignId, recipient, amount);
    }

    // ── User functions ───────────────────────────────────────────────────────

    function registerUser(string memory displayName) public {
        require(!registered[msg.sender], "Already registered");
        require(bytes(displayName).length > 0, "Name cannot be empty");
        userNames[msg.sender] = displayName;
        registered[msg.sender] = true;
        emit UserRegistered(msg.sender, displayName);
    }

    function donate(uint campaignId) public payable whenNotPaused {
        require(campaignId < campaigns.length, "Invalid campaign ID");
        require(msg.value > 0, "Must send ETH");

        campaigns[campaignId].totalDonated += msg.value;

        // Reward: 100 DNC per 1 wei (scaled)
        uint reward = msg.value * 100;
        donorCoin.mint(msg.sender, reward);

        emit Donated(msg.sender, campaignId, msg.value);
    }

    // ── View functions ───────────────────────────────────────────────────────

    function getCampaign(uint id) public view returns (
        string memory, string memory, uint, uint
    ) {
        require(id < campaigns.length, "Invalid campaign ID");
        Campaign memory c = campaigns[id];
        return (c.name, c.description, c.target, c.totalDonated);
    }

    function getCampaignCount() public view returns (uint) {
        return campaigns.length;
    }

    function getAdmin() public view returns (address) {
        return admin;
    }

    function getUserName(address user) public view returns (string memory) {
        return userNames[user];
    }

    function isRegistered(address user) public view returns (bool) {
        return registered[user];
    }
}
"""

# ── Compile ────────────────────────────────────────────────────────────────────
print("\n📦  Installing solc 0.8.0 …")
install_solc("0.8.0")
print("    Done.")

print("🔨  Compiling contracts …")

compiled = compile_standard({
    "language": "Solidity",
    "sources": {
        "DonorCoin.sol":       {"content": DONOR_COIN_SOURCE},
        "CharityTracker.sol":  {"content": CHARITY_TRACKER_SOURCE},
    },
    "settings": {
        "outputSelection": {
            "*": {"*": ["abi", "evm.bytecode"]}
        }
    }
}, solc_version="0.8.0")

coin_abi      = compiled["contracts"]["DonorCoin.sol"]["DonorCoin"]["abi"]
coin_bytecode = compiled["contracts"]["DonorCoin.sol"]["DonorCoin"]["evm"]["bytecode"]["object"]

charity_abi      = compiled["contracts"]["CharityTracker.sol"]["CharityTracker"]["abi"]
charity_bytecode = compiled["contracts"]["CharityTracker.sol"]["CharityTracker"]["evm"]["bytecode"]["object"]

print("    Compilation successful.")

# ── Deploy DonorCoin ───────────────────────────────────────────────────────────
print("\n🚀  Deploying DonorCoin …")
CoinContract = w3.eth.contract(abi=coin_abi, bytecode=coin_bytecode)
tx_hash = CoinContract.constructor(ADMIN_ACCOUNT).transact({
    "from": ADMIN_ACCOUNT,
    "gas":  3_000_000
})
coin_receipt   = w3.eth.wait_for_transaction_receipt(tx_hash)
COIN_ADDRESS   = coin_receipt.contractAddress
print(f"    DonorCoin deployed at : {COIN_ADDRESS}")

# ── Deploy CharityTracker ──────────────────────────────────────────────────────
print("🚀  Deploying CharityTracker …")
CharityContract = w3.eth.contract(abi=charity_abi, bytecode=charity_bytecode)
tx_hash = CharityContract.constructor(COIN_ADDRESS).transact({
    "from": ADMIN_ACCOUNT,
    "gas":  5_000_000
})
charity_receipt  = w3.eth.wait_for_transaction_receipt(tx_hash)
CHARITY_ADDRESS  = charity_receipt.contractAddress
print(f"    CharityTracker deployed at : {CHARITY_ADDRESS}")

# ── Contract instances ─────────────────────────────────────────────────────────
charity = w3.eth.contract(address=CHARITY_ADDRESS, abi=charity_abi)
coin    = w3.eth.contract(address=COIN_ADDRESS,    abi=coin_abi)

# ── Authorise CharityTracker to mint DNC ──────────────────────────────────────
# The DonorCoin admin is ADMIN_ACCOUNT; CharityTracker calls coin.mint() from
# its own address, so we need to transfer coin admin to the charity contract.
print("\n🔑  Transferring DonorCoin admin rights to CharityTracker …")
tx = coin.functions.transferOwnership(CHARITY_ADDRESS).transact({   # type: ignore[attr-defined]
    "from": ADMIN_ACCOUNT,
    "gas":  200_000
})
w3.eth.wait_for_transaction_receipt(tx)
print("    Done — CharityTracker can now mint DNC rewards.")

# ── Seed 5 sample campaigns ────────────────────────────────────────────────────
print("\n🌱  Seeding 5 sample campaigns …")
CAMPAIGNS = [
    ("Clean Water Initiative",   "Providing clean drinking water to rural areas",     w3.to_wei(10, "ether")),
    ("Education for All",        "Building schools in underprivileged communities",   w3.to_wei(20, "ether")),
    ("Food Relief Program",      "Emergency food aid for disaster-affected families", w3.to_wei(15, "ether")),
    ("Tree Planting Drive",      "Plant 1 million trees to fight climate change",     w3.to_wei(5,  "ether")),
    ("Medical Supplies Fund",    "Medicine and equipment for remote clinics",         w3.to_wei(25, "ether")),
]
for name, desc, target in CAMPAIGNS:
    tx = charity.functions.addCampaign(name, desc, target).transact({
        "from": ADMIN_ACCOUNT,
        "gas":  300_000
    })
    w3.eth.wait_for_transaction_receipt(tx)
    print(f"    ✔  {name}")

# ── Mint 1,000,000 DNC to admin directly via charity (admin only) ─────────────
# Because coin admin is now the charity contract, we mint through addCampaign
# rewards or we call a special path.  Instead, seed some donations so admin
# has DNC and there is on-chain history.
print("\n💰  Seeding sample donations from accounts[1..4] …")
for i in range(1, 5):
    donor    = w3.eth.accounts[i]
    campaign = i - 1
    amount   = w3.to_wei(0.5 * i, "ether")
    tx = charity.functions.donate(campaign).transact({
        "from":  donor,
        "value": amount,
        "gas":   200_000
    })
    w3.eth.wait_for_transaction_receipt(tx)
    print(f"    ✔  Account {i} donated {0.5 * i} ETH to campaign {campaign}")

# ── Save addresses + ABIs ──────────────────────────────────────────────────────
addresses = {
    "charity_contract": CHARITY_ADDRESS,
    "coin_contract":    COIN_ADDRESS,
    "admin":            ADMIN_ACCOUNT
}
with open("deployed_addresses.json", "w") as f:
    json.dump(addresses, f, indent=2)

abis = {
    "charity_abi": charity_abi,
    "coin_abi":    coin_abi
}
with open("contract_abis.json", "w") as f:
    json.dump(abis, f, indent=2)

print("\n✅  deployed_addresses.json  — saved")
print("✅  contract_abis.json       — saved")
print("\n🎉  Setup complete! Run:  python terminal_app.py")
