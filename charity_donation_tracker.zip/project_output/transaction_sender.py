"""
transaction_sender.py - Blockchain Write/Read Functions
Charity Donation Tracker

All functions that send or read transactions from the blockchain.
Imported by terminal_app.py.
"""

import json
from web3 import Web3
from web3_connection import get_connection, wei_to_eth, eth_to_wei

# ── Load deployment data ───────────────────────────────────────────────────────
def _load_contracts():
    try:
        with open("deployed_addresses.json") as f:
            addresses = json.load(f)
        with open("contract_abis.json") as f:
            abis = json.load(f)
        return addresses, abis
    except FileNotFoundError:
        print("❌  deployed_addresses.json not found.")
        print("    Run:  python auto_setup.py  first.")
        exit(1)


w3 = get_connection()
addresses, abis = _load_contracts()

CHARITY_ADDRESS = Web3.to_checksum_address(addresses["charity_contract"])
COIN_ADDRESS    = Web3.to_checksum_address(addresses["coin_contract"])

charity = w3.eth.contract(address=CHARITY_ADDRESS, abi=abis["charity_abi"])
coin    = w3.eth.contract(address=COIN_ADDRESS,    abi=abis["coin_abi"])


# ══════════════════════════════════════════════════════════════════════════════
# READ FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_campaign_count() -> int:
    return charity.functions.getCampaignCount().call()


def get_campaign(cid: int) -> dict:
    name, desc, target, raised = charity.functions.getCampaign(cid).call()
    return {
        "id":     cid,
        "name":   name,
        "desc":   desc,
        "target": target,
        "raised": raised,
    }


def get_all_campaigns() -> list:
    count = get_campaign_count()
    return [get_campaign(i) for i in range(count)]


def get_coin_balance(address: str) -> float:
    raw = coin.functions.balanceOf(Web3.to_checksum_address(address)).call()
    return raw / (10 ** 18)


def get_eth_balance(address: str) -> float:
    raw = w3.eth.get_balance(Web3.to_checksum_address(address))
    return wei_to_eth(raw)


def get_admin() -> str:
    return charity.functions.getAdmin().call()


def is_registered(address: str) -> bool:
    return charity.functions.isRegistered(Web3.to_checksum_address(address)).call()


def get_user_name(address: str) -> str:
    return charity.functions.getUserName(Web3.to_checksum_address(address)).call()


def is_paused() -> bool:
    return charity.functions.paused().call()


# ══════════════════════════════════════════════════════════════════════════════
# WRITE FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def register_user(sender: str, private_key: str, display_name: str) -> dict:
    """Register a display name for the caller's wallet address."""
    checksum = Web3.to_checksum_address(sender)
    tx = charity.functions.registerUser(display_name).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   200_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return receipt


def donate(sender: str, private_key: str, campaign_id: int, eth_amount: float) -> dict:
    """Donate ETH to a campaign and receive DNC rewards."""
    checksum = Web3.to_checksum_address(sender)
    wei_amt  = eth_to_wei(eth_amount)
    tx = charity.functions.donate(campaign_id).build_transaction({
        "from":  checksum,
        "value": wei_amt,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   300_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return receipt


def add_campaign(sender: str, private_key: str,
                 name: str, desc: str, target_eth: float) -> dict:
    """Admin: add a single campaign."""
    checksum = Web3.to_checksum_address(sender)
    target   = eth_to_wei(target_eth)
    tx = charity.functions.addCampaign(name, desc, target).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   300_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return receipt


def update_campaign(sender: str, private_key: str,
                    cid: int, name: str, desc: str, target_eth: float) -> dict:
    """Admin: update an existing campaign."""
    checksum = Web3.to_checksum_address(sender)
    target   = eth_to_wei(target_eth)
    tx = charity.functions.updateCampaign(cid, name, desc, target).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   300_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return receipt


def batch_add_campaigns(sender: str, private_key: str,
                        names: list, descs: list, targets_eth: list) -> dict:
    """Admin: batch add multiple campaigns in one transaction."""
    checksum = Web3.to_checksum_address(sender)
    targets  = [eth_to_wei(t) for t in targets_eth]
    tx = charity.functions.batchAddCampaigns(names, descs, targets).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   1_000_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return receipt


def mint_coins(sender: str, private_key: str, to: str, amount: float) -> dict:
    """Admin: mint DNC tokens via CharityTracker.adminMint (charity contract is DonorCoin admin)."""
    checksum    = Web3.to_checksum_address(sender)
    to_checksum = Web3.to_checksum_address(to)
    raw_amount  = int(amount * (10 ** 18))
    tx = charity.functions.adminMint(to_checksum, raw_amount).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   200_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return receipt


def pause_contract(sender: str, private_key: str) -> dict:
    checksum = Web3.to_checksum_address(sender)
    tx = charity.functions.pause().build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   100_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    return w3.eth.wait_for_transaction_receipt(tx_hash)


def resume_contract(sender: str, private_key: str) -> dict:
    checksum = Web3.to_checksum_address(sender)
    tx = charity.functions.resume().build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   100_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    return w3.eth.wait_for_transaction_receipt(tx_hash)


def transfer_ownership(sender: str, private_key: str, new_admin: str) -> dict:
    checksum      = Web3.to_checksum_address(sender)
    new_checksum  = Web3.to_checksum_address(new_admin)
    tx = charity.functions.transferOwnership(new_checksum).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   100_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    return w3.eth.wait_for_transaction_receipt(tx_hash)


def withdraw_funds(sender: str, private_key: str,
                   campaign_id: int, recipient: str) -> dict:
    """Admin: withdraw raised ETH from a campaign."""
    checksum   = Web3.to_checksum_address(sender)
    rec_check  = Web3.to_checksum_address(recipient)
    tx = charity.functions.withdraw(campaign_id, rec_check).build_transaction({
        "from":  checksum,
        "nonce": w3.eth.get_transaction_count(checksum),
        "gas":   200_000,
    })
    signed  = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    return w3.eth.wait_for_transaction_receipt(tx_hash)
