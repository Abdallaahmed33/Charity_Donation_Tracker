"""
ownership_transfer_test.py - Ownership Transfer Test
Charity Donation Tracker

Full test sequence:
  1. Admin does an action (add campaign) ✅
  2. Admin transfers ownership to accounts[1]
  3. Old admin tries the same action → should FAIL ✅
  4. New admin does the action → should SUCCEED ✅
  5. New admin transfers ownership back to original admin

    python ownership_transfer_test.py
"""

import json
from web3 import Web3
from web3.exceptions import ContractLogicError

# ── Connect ────────────────────────────────────────────────────────────────────
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

if not w3.is_connected():
    print("❌  Cannot connect to Ganache.")
    exit(1)

try:
    with open("deployed_addresses.json") as f:
        addresses = json.load(f)
    with open("contract_abis.json") as f:
        abis = json.load(f)
except FileNotFoundError:
    print("❌  Run auto_setup.py first.")
    exit(1)

charity = w3.eth.contract(
    address=Web3.to_checksum_address(addresses["charity_contract"]),
    abi=abis["charity_abi"]
)

ORIGINAL_ADMIN = Web3.to_checksum_address(addresses["admin"])
NEW_ADMIN      = Web3.to_checksum_address(w3.eth.accounts[1])

results = []

def check(label: str, passed: bool):
    status = "✅ PASS" if passed else "❌ FAIL"
    results.append((label, status))
    print(f"  {status}  {label}")


print("\n" + "═" * 64)
print("  CHARITY DONATION TRACKER — OWNERSHIP TRANSFER TEST")
print("═" * 64)
print(f"  Original admin : {ORIGINAL_ADMIN}")
print(f"  New admin      : {NEW_ADMIN}")
print("─" * 64)

# ── Step 1: Original admin adds a campaign ─────────────────────────────────────
print("\n  Step 1 — Original admin adds a campaign …")
try:
    tx = charity.functions.addCampaign(
        "Pre-Transfer Test", "Added before ownership transfer", w3.to_wei(1, "ether")
    ).transact({"from": ORIGINAL_ADMIN, "gas": 300_000})
    w3.eth.wait_for_transaction_receipt(tx)
    check("Original admin can add a campaign", True)
except Exception as e:
    print(f"    Error: {e}")
    check("Original admin can add a campaign", False)

# ── Step 2: Transfer ownership ─────────────────────────────────────────────────
print("\n  Step 2 — Transferring ownership to new admin …")
try:
    tx = charity.functions.transferOwnership(NEW_ADMIN).transact(
        {"from": ORIGINAL_ADMIN, "gas": 100_000}
    )
    w3.eth.wait_for_transaction_receipt(tx)
    current_admin = charity.functions.getAdmin().call()
    check("Ownership transferred to new admin", current_admin.lower() == NEW_ADMIN.lower())
    print(f"    Contract admin is now: {current_admin}")
except Exception as e:
    print(f"    Error: {e}")
    check("Ownership transferred to new admin", False)

# ── Step 3: Old admin tries to add a campaign (should fail) ───────────────────
print("\n  Step 3 — Old admin tries to add a campaign (should fail) …")
reverted = False
try:
    charity.functions.addCampaign(
        "Should Fail", "Old admin should not do this", w3.to_wei(1, "ether")
    ).transact({"from": ORIGINAL_ADMIN, "gas": 300_000})
except (ContractLogicError, Exception) as e:
    err = str(e).lower()
    if "revert" in err or "only admin" in err or "not admin" in err or "execution reverted" in err:
        reverted = True
check("Old admin is now blocked from admin actions", reverted)

# ── Step 4: New admin adds a campaign (should succeed) ────────────────────────
print("\n  Step 4 — New admin adds a campaign (should succeed) …")
try:
    tx = charity.functions.addCampaign(
        "Post-Transfer Test", "Added after ownership transfer", w3.to_wei(2, "ether")
    ).transact({"from": NEW_ADMIN, "gas": 300_000})
    w3.eth.wait_for_transaction_receipt(tx)
    check("New admin can add a campaign", True)
except Exception as e:
    print(f"    Error: {e}")
    check("New admin can add a campaign", False)

# ── Step 5: Restore original admin ────────────────────────────────────────────
print("\n  Step 5 — Restoring ownership to original admin …")
try:
    tx = charity.functions.transferOwnership(ORIGINAL_ADMIN).transact(
        {"from": NEW_ADMIN, "gas": 100_000}
    )
    w3.eth.wait_for_transaction_receipt(tx)
    current_admin = charity.functions.getAdmin().call()
    check("Ownership restored to original admin", current_admin.lower() == ORIGINAL_ADMIN.lower())
    print(f"    Contract admin is now: {current_admin}")
except Exception as e:
    print(f"    Error: {e}")
    check("Ownership restored to original admin", False)

# ── Summary ────────────────────────────────────────────────────────────────────
print("\n" + "─" * 64)
passed = sum(1 for _, s in results if "PASS" in s)
total  = len(results)
print(f"  Result: {passed}/{total} tests passed\n")

if passed == total:
    print("  🎉  Ownership transfer test PASSED completely!")
else:
    print("  ⚠️   Some steps failed — check the output above.")
print()
